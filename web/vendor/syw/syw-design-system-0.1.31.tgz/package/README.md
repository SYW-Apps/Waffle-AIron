# SYW Design System

Framework-neutral design system for SYW Apps and SYW products.

**Scope status:** the published system is a usable foundation and documented
component subset, not the full Waffler feature set. Shared JSON form generation,
expression/condition controls, rich theme authoring, composed templates and
reusable canvas/style-profile modules remain unfinished. Read the
[coverage and extraction plan](docs/scope-and-coverage.md) before replacing an
existing form, theme builder or editor.

The browser contract is CSS custom properties + stable `.syw-*` classes + optional small runtime helpers. React, MUI, Jinja, static HTML and Tauri consume the same contract rather than reimplementing the visual language.

## Principles

- **Foundation is context-free.** No global `overflow: hidden`, fixed viewport shell, forced header, or application-only assumptions.
- **Configuration is a feature.** Theme, mode, density, text size, font, motion and layout preferences are first-class.
- **Semantic tokens are the public contract.** Components consume semantic variables, not literal brand colours.
- **Shells are explicit.** Website, app, workspace, media and bare experiences opt into their layout behavior.
- **Progressive adoption.** Existing products can use compatibility aliases and migrate component-by-component.
- **Framework adapters are thin.** They render the same DOM/CSS contract rather than owning the design language.
- **Accessibility wins over brand literals.** Themes may use mode-specific readable variants.
- **Releases are versioned and distributable by package and CDN.**

## Packages and release surfaces

- `@syw/design-system` — framework-neutral CSS, themes, runtime, color tools, tokens, schemas and catalogue metadata.
- `color.js` / `@syw/design-system/color` — independent color/contrast computation and palette harmonies; no framework, DOM or stylesheet dependency.
- `@syw/design-react` — thin React wrappers around the shared `.syw-*` DOM/CSS contract.
- `@syw/design-mui` — MUI-facing semantic-variable adapter without owning theme values.
- `@syw/design-toastify` — optional React Toastify 11 adapter and theme-aware skin; see [overlays and enforcement](docs/overlays.md).
- `@syw/forms-core` — experimental standalone Waffler-compatible form computation and pure field-list builder operations; the opt-in `@syw/forms-core/expression` subpath supplies token/argument/condition computation without styling, frameworks or execution. See [form core](docs/forms-core.md) and [expressions](docs/expressions.md); the opt-in [input editing](docs/input-editing.md) subpath adds headless atomic pill and condition operations. The visual form/builder and pill/condition UI remain unfinished.
- `themes` — SYW Apps, Waffler and Neutral structured built-in theme sources.
- `examples/catalogue` — live release consumer/prototype for the future catalogue application.

The framework-neutral core never depends on React or MUI. Adapter packages are built and pack-validated independently so framework peer dependencies cannot leak into the core package.

Package-ready artifacts are emitted with each immutable release; automatic publication to npm/GitHub Packages is intentionally a separate registry/credential step.

## Start here

Start at the public `docs/implementation.md` guide, select the application's
framework/platform page, and use the exact release's `llms.txt`, `docs/agent-guide.md`,
`catalogue.json` and `manifest.json` together. They are included in CDN releases
and the core tarball. The release-local `examples/catalogue/index.html` provides
interactive selection/dialog examples, appearance controls and copyable code.
React examples cover available wrappers and native dialog composition; other
components use the same semantic HTML/JSX contract.

The [theme-builder parity audit](docs/theme-builder-parity.md) records capabilities
that the current portable theme contract does not yet represent. Consumers retain
existing theme generation, dynamic contrast checks and richer saved data until a
reviewed migration preserves them. Consumer sessions own their migrations.

## Build

```bash
node scripts/build.mjs
```

Outputs deployable CDN artifacts and package-ready release roots into `dist/`.

See `docs/architecture.md`, `docs/versioning.md`, `docs/adoption.md`, and `docs/distribution.md`.

See `docs/consumers.md` for active adoption and the Authentik integration follow-through.
