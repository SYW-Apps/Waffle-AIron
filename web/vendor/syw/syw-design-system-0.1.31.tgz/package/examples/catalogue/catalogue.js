import { DEMO_SETUP } from "./interactions.js";

const root = document.documentElement;
const catalogueEl = document.querySelector('#catalogue');
const searchEl = document.querySelector('#search');
const kindEl = document.querySelector('#kind');
const statusEl = document.querySelector('#status');
const themeEl = document.querySelector('#theme');
const modeEl = document.querySelector('#mode');
const densityEl = document.querySelector('#density');
const textSizeEl = document.querySelector('#text-size');
const motionEl = document.querySelector('#motion');
const statsEl = document.querySelector('#stats');

const [catalogue, builtins, manifest] = await Promise.all([
  fetch('../../catalogue.json').then(assertJson),
  fetch('../../themes/builtins.json').then(assertJson),
  fetch('../../manifest.json').then(assertJson),
]);

const themes = normalizeThemes(builtins);
for (const theme of themes) {
  const option = document.createElement('option');
  option.value = theme.id;
  option.textContent = theme.name || theme.id;
  themeEl.append(option);
}
await Promise.all(themes.map(theme => new Promise((resolve, reject) => {
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = `../../themes/${theme.id}.css`;
  link.onload = resolve;
  link.onerror = () => reject(new Error(`Unable to load theme ${theme.id}`));
  document.head.append(link);
})));
themeEl.value = root.getAttribute('data-theme') || 'syw-apps';
modeEl.value = root.getAttribute('data-mode') || 'dark';
densityEl.value = root.getAttribute('data-density') || 'cozy';
textSizeEl.value = root.getAttribute('data-text-size') || 'default';
motionEl.value = root.getAttribute('data-motion') || 'full';

function assertJson(response) {
  if (!response.ok) throw new Error(`Unable to load ${response.url} (${response.status})`);
  return response.json();
}

function normalizeThemes(value) {
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.themes)) return value.themes;
  if (value && typeof value === 'object') return Object.values(value);
  return [];
}

function text(value) {
  return document.createTextNode(String(value));
}

function chip(label) {
  const el = document.createElement('span');
  el.className = 'syw-chip';
  el.append(text(label));
  return el;
}

function render() {
  const needle = searchEl.value.trim().toLowerCase();
  const kind = kindEl.value;
  const status = statusEl.value;
  const items = catalogue.items.filter((item) => {
    const searchable = [
      item.id,
      item.name,
      item.description,
      item.accessibility,
      item.supportProfile,
      ...(item.tags || []),
      ...(item.classes || []),
      ...(item.tokens || []),
    ].join(' ').toLowerCase();
    return (!needle || searchable.includes(needle)) && (!kind || item.kind === kind) && (!status || item.status === status);
  });

  catalogueEl.replaceChildren();
  statsEl.replaceChildren(
    chip(`release ${manifest.version}`),
    chip(`${items.length}/${catalogue.items.length} shown`),
    chip(`${themes.length} themes`),
  );

  if (!items.length) {
    const empty = document.createElement('div');
    empty.className = 'catalogue-empty syw-card';
    empty.textContent = 'No catalogue items match these filters.';
    catalogueEl.append(empty);
    return;
  }

  for (const item of items) catalogueEl.append(renderItem(item));
}

function renderItem(item) {
  const card = document.createElement('article');
  card.className = 'catalogue-item syw-card';
  card.id = item.id;

  const heading = document.createElement('div');
  const title = document.createElement('h2');
  const permalink = document.createElement('a');
  permalink.href = `#${item.id}`;
  permalink.textContent = item.name;
  title.append(permalink);
  const description = document.createElement('p');
  description.className = 'syw-page-header__subtitle';
  description.textContent = item.description;
  const meta = document.createElement('div');
  meta.className = 'catalogue-meta';
  meta.append(chip(item.kind), chip(item.status), chip(`since ${item.since}`), chip(item.supportProfile));
  heading.append(title, description, meta);

  const preview = document.createElement('div');
  preview.className = 'catalogue-preview';
  preview.innerHTML = item.exampleHtml;
  preparePreview(preview);
  DEMO_SETUP[item.id]?.(preview.querySelector('[data-syw-example]'));
  const usage = document.createElement('p');
  usage.className = 'catalogue-example-note';
  usage.textContent = item.exampleJavaScript
    ? 'Interactive example. Copy HTML and JavaScript together; CSS alone supplies presentation.'
    : 'Presentation example. Actions and application data are supplied by the consumer.';

  const code = document.createElement('div');
  code.className = 'catalogue-examples';
  code.append(renderCode('HTML', item.exampleHtml, item.name, true));
  if (item.exampleJavaScript) code.append(renderCode('JavaScript', item.exampleJavaScript, item.name));
  if (item.exampleReact) code.append(renderCode('React', item.exampleReact, item.name));

  const details = document.createElement('div');
  details.className = 'catalogue-details';
  details.append(detailGroup('Classes', item.classes, 'catalogue-class-list'));
  if (item.tokens?.length) details.append(detailGroup('Semantic tokens', item.tokens, 'catalogue-token-list'));
  details.append(renderSupport(item));
  details.append(renderAccessibility(item));

  card.append(heading, usage, preview, code, details);
  return card;
}

function renderSupport(item) {
  const profile = catalogue.supportProfiles?.[item.supportProfile];
  const group = document.createElement('div');
  group.className = 'catalogue-guidance';
  const heading = document.createElement('strong');
  heading.textContent = 'Appearance support';
  const list = document.createElement('div');
  list.className = 'catalogue-token-list';
  if (profile) {
    list.append(
      chip(profile.themes === 'all' ? 'all themes' : String(profile.themes)),
      ...profile.modes.map((value) => chip(value)),
      ...profile.densities.map((value) => chip(value)),
      ...profile.textSizes.map((value) => chip(`text ${value}`)),
      chip(profile.motion),
    );
  }
  group.append(heading, list);
  return group;
}

function renderAccessibility(item) {
  const group = document.createElement('div');
  group.className = 'catalogue-guidance';
  const heading = document.createElement('strong');
  heading.textContent = 'Accessibility';
  const note = document.createElement('p');
  note.textContent = item.accessibility;
  group.append(heading, note);
  return group;
}

function detailGroup(label, values, className) {
  const group = document.createElement('div');
  const heading = document.createElement('strong');
  heading.textContent = label;
  const list = document.createElement('div');
  list.className = className;
  for (const value of values) list.append(chip(value));
  group.append(heading, list);
  return group;
}

function renderCode(language, source, name, open = false) {
  const details = document.createElement('details');
  details.open = open;
  const summary = document.createElement('summary');
  summary.textContent = language;
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'syw-button';
  button.textContent = `Copy ${language}`;
  button.setAttribute('aria-label', `Copy ${language} for ${name}`);
  const status = document.createElement('span');
  status.setAttribute('role', 'status');
  const pre = document.createElement('pre');
  pre.className = 'catalogue-code';
  pre.tabIndex = 0;
  pre.setAttribute('aria-label', `${language} example for ${name}`);
  const code = document.createElement('code');
  code.textContent = source;
  pre.append(code);
  button.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(source);
      status.textContent = `${language} copied.`;
    } catch {
      status.textContent = 'Clipboard unavailable. Select the code below to copy it.';
      pre.focus();
    }
  });
  details.append(summary, button, status, pre);
  return details;
}

function preparePreview(container) {
  // Keep examples keyboard reachable; prevent sample navigation and unavailable
  // actions without giving presentation-only examples application side effects.
  for (const node of container.querySelectorAll('a')) node.removeAttribute('href');
  container.addEventListener('click', event => {
    if (event.target.closest('[aria-disabled="true"]')) event.preventDefault();
  });
  for (const image of container.querySelectorAll('img')) {
    image.addEventListener('error', () => image.remove(), { once: true });
  }
}

for (const el of [searchEl, kindEl, statusEl]) el.addEventListener('input', render);
for (const [control, attribute] of [
  [themeEl, 'data-theme'], [modeEl, 'data-mode'], [densityEl, 'data-density'],
  [textSizeEl, 'data-text-size'], [motionEl, 'data-motion'],
]) control.addEventListener('change', () => root.setAttribute(attribute, control.value));
render();

if (location.hash) document.getElementById(location.hash.slice(1))?.scrollIntoView();
