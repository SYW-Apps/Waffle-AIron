// These self-contained functions also supply the catalogue's copyable JS.
// They are examples owned by this preview, not automatic core behaviour.
export function setupSelectionExample(root) {
  function activate(button, group) {
    const tabs = group.getAttribute('role') === 'tablist';
    const state = tabs ? 'aria-selected' : 'aria-checked';
    for (const item of group.querySelectorAll('button')) {
      const selected = item === button;
      item.setAttribute(state, String(selected));
      item.tabIndex = selected ? 0 : -1;
      if (tabs) {
        const panel = [...root.querySelectorAll('[role="tabpanel"]')].find(node => node.id === item.getAttribute('aria-controls'));
        if (panel) panel.hidden = !selected;
      }
    }
    button.focus({ preventScroll: true });
    if (tabs) button.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "instant" });
  }
  root.addEventListener('click', event => {
    const button = event.target.closest('button');
    const group = button?.closest('[role="radiogroup"], [role="tablist"]');
    if (group && root.contains(group) && !button.disabled) activate(button, group);
  });
  root.addEventListener('keydown', event => {
    if (event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey) return;
    const button = event.target.closest('button');
    const group = button?.closest('[role="radiogroup"], [role="tablist"]');
    if (!group || !root.contains(group)) return;
    const items = [...group.querySelectorAll('button')].filter(item => !item.disabled);
    const index = items.indexOf(button);
    if (index < 0) return;
    const radio = group.getAttribute('role') === 'radiogroup';
    const vertical = group.getAttribute('aria-orientation') === 'vertical';
    let next;
    if (event.key === 'Home') next = 0;
    else if (event.key === 'End') next = items.length - 1;
    else if ((event.key === 'ArrowRight' && (!vertical || radio)) || (event.key === 'ArrowDown' && (vertical || radio))) next = (index + 1) % items.length;
    else if ((event.key === 'ArrowLeft' && (!vertical || radio)) || (event.key === 'ArrowUp' && (vertical || radio))) next = (index - 1 + items.length) % items.length;
    else return;
    event.preventDefault();
    activate(items[next], group);
  });
}

export function setupDialogExample(root) {
  const dialog = root.querySelector('dialog');
  const invoker = root.querySelector('[data-demo-open]');
  invoker.addEventListener('click', () => dialog.showModal());
  for (const button of dialog.querySelectorAll('[data-demo-close]')) {
    button.addEventListener('click', () => dialog.close());
  }
  dialog.addEventListener('close', () => invoker.focus({ preventScroll: true }));
}

export const DEMO_SETUP = {
  'segmented-control': setupSelectionExample,
  tabs: setupSelectionExample,
  dialog: setupDialogExample,
};
