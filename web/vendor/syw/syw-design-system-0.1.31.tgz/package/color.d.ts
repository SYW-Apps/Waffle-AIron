export interface SywRgbaColor { r: number; g: number; b: number; a: number; }
export interface SywRgbColor { r: number; g: number; b: number; }
export interface SywHslColor { h: number; s: number; l: number; }
export interface SywContrastOptions { underlay?: string; }
export interface SywContrastResolution {
  color: string;
  ratio: number;
  targetRatio: number;
  meetsTarget: boolean;
  adjusted: boolean;
  reason: 'already-passes' | 'adjusted' | 'unreachable';
}
export interface SywTextColorPair extends SywContrastOptions {
  foreground: string;
  background: string;
}
/** HEX (3/4/6/8), rgb[a], hsl[a], or transparent. Unsupported input throws. */
export function parseColor(color: string): SywRgbaColor;
/** Opaque color to 8-bit HEX. Translucent input throws. */
export function toHex(color: string): string;
/** Hue is degrees; saturation and lightness are fractions in 0..1. */
export function hslToRgb(h: number, s: number, l: number): SywRgbColor;
/** Channels are in 0..255. */
export function rgbToHsl(r: number, g: number, b: number): SywHslColor;
/** Source-over in encoded sRGB; output retains alpha if both inputs are translucent. */
export function compositeColors(foreground: string, background: string): string;
/** Opaque sRGB relative luminance. */
export function getLuminance(color: string): number;
/** Alpha foreground is composited; alpha background needs an opaque underlay. */
export function getContrastRatio(foreground: string, background: string, options?: SywContrastOptions): number;
/** Hue/saturation/alpha-preserving HSL lightness search, with verified output. */
export function resolveAccessibleColor(foreground: string, background: string, targetRatio?: number, options?: SywContrastOptions): SywContrastResolution;
/** Throws RangeError when the target cannot be reached at the supplied alpha/background. */
export function findClosestAccessibleColor(foreground: string, background: string, targetRatio?: number, options?: SywContrastOptions): string;
export function rotateHue(color: string, degrees: number): string;
/** Additive HSL lightness delta in -1..1, clamped at black/white. */
export function adjustLightness(color: string, delta: number): string;
/** Weight in 0..1 belongs to first; premultiplied encoded-sRGB interpolation. */
export function mixColors(first: string, second: string, weight?: number): string;
/** Replace alpha, preserving RGB channels. */
export function withAlpha(color: string, alpha: number): string;
export function getColorHarmonies(primary: string): {
  primary: string;
  complement: string;
  triadic: [string, string, string];
  tetradic: [string, string, string, string];
  analogous: [string, string, string];
  splitComplementary: [string, string, string];
};
export function resolveTextColors<K extends string>(pairs: Record<K, SywTextColorPair>, targetRatio?: number): {
  colors: Record<K, string>;
  results: Record<K, SywContrastResolution>;
  meetsTarget: boolean;
};
