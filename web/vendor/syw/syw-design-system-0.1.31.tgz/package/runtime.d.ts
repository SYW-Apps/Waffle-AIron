export type SywThemeKind = 'builtin' | 'custom';
export type SywMode = 'auto' | 'light' | 'dark' | 'high-contrast';
export type SywDensity = 'cozy' | 'compact';
export type SywTextSize = 'small' | 'default' | 'large';
export type SywFont = 'system' | 'inter' | 'classic' | 'serif' | 'mono';
export type SywMotion = 'full' | 'reduced';

export interface SywThemeRef {
  kind: SywThemeKind;
  id: string;
}

export interface SywAppearanceValues {
  theme: SywThemeRef;
  mode: SywMode;
  density: SywDensity;
  textSize: SywTextSize;
  font: SywFont;
  motion: SywMotion;
}

export type SywAppearanceOverride = Partial<SywAppearanceValues>;

export interface SywAppearanceProfile extends SywAppearanceValues {
  schemaVersion: 1;
  appOverrides?: Record<string, SywAppearanceOverride>;
}

export interface SywThemePalette {
  canvas: string;
  surface: string;
  surfaceRaised: string;
  text: string;
  textMuted: string;
  line: string;
  lineStrong: string;
  primary: string;
  secondary: string;
  accent: string;
  onPrimary: string;
  danger: string;
  onDanger: string;
  success: string;
  warning: string;
}

export interface SywCustomTheme {
  schemaVersion: 1;
  id: string;
  name: string;
  description?: string;
  modes: {
    light: SywThemePalette;
    dark: SywThemePalette;
    highContrast?: SywThemePalette;
  };
}

export interface SywAppearanceState {
  schemaVersion: 1;
  revision: string;
  updatedAt: string;
  profile: SywAppearanceProfile;
  customThemes: SywCustomTheme[];
}

export interface SywValidationResult {
  valid: boolean;
  errors: string[];
}

export interface SywRuntimeTargetOptions {
  root?: HTMLElement;
  prefix?: string;
}

export interface SywDocumentOptions extends SywRuntimeTargetOptions {
  document?: Document;
}

export interface SywAppearanceInput {
  theme?: string | null;
  mode?: SywMode | null;
  density?: SywDensity | null;
  textSize?: SywTextSize | null;
  font?: SywFont | null;
  motion?: SywMotion | null;
}

export interface SywResolvedAppearance {
  theme: string;
  mode: 'light' | 'dark' | 'high-contrast';
  density: SywDensity;
  textSize: SywTextSize;
  font: SywFont;
  motion: SywMotion;
}

export function validateCustomTheme(theme: unknown): SywValidationResult;
export function validateAppearanceProfile(profile: unknown): SywValidationResult;
export function validateAppearanceState(state: unknown): SywValidationResult;

export function installCustomTheme(
  theme: SywCustomTheme,
  options?: SywDocumentOptions & { activate?: boolean },
): () => boolean;

export function removeCustomTheme(
  themeId: string,
  options?: Pick<SywDocumentOptions, 'document'>,
): boolean;

export function applyAppearanceState(
  state: SywAppearanceState,
  options?: SywDocumentOptions & {
    appId?: string;
    pruneStateThemes?: boolean;
  },
): {
  revision: string;
  updatedAt: string;
  appId: string | null;
  customThemeIds: string[];
  appearance: SywResolvedAppearance;
};

export function setAppearance(next?: SywAppearanceInput, options?: SywRuntimeTargetOptions): void;
export function getAppearance(options?: SywRuntimeTargetOptions): SywResolvedAppearance;

export function makeResizableSidebar(options: {
  shell: string | HTMLElement;
  handle: string | HTMLElement;
  min?: number;
  max?: number;
  storageKey?: string;
}): () => void;
