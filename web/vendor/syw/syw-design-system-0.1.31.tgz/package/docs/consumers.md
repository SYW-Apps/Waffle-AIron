# Active consumers

The Design System is the product. Consumers validate its shared contracts and feed reusable fixes back into core.

| Consumer | Current adoption | Consumer-owned responsibilities |
| --- | --- | --- |
| `SYW-Apps/syw-authentik-overlay` | Active since the initial integration; deployed overlay 0.2.8 uses shared native-dialog structure, fields, validation states, buttons, inputs, cards, segmented controls, settings, tabs and empty states. Exact 0.1.23 CDN assets are verified and bundled into the derived image at build time. | Authentik route/theme isolation, appearance storage, validation/recovery behavior, palette previews, custom-theme editing and the floating launcher. |
| `SYW-Apps/syw-cdn` | Active React 19.3.0 consumer deployed with exact 0.1.24 core/adapter packages, including the publisher form's segmented control; also supplies distribution and publisher CI. | Asset browsing, publisher administration, routing and application data. |
| `examples/catalogue` | Release-local HTML consumer of generated catalogue metadata and CSS. | Discovery, filtering and static component previews. |

## Additional consumers found in the source audit

`SYW-Apps/Traqolic` is already a versioned consumer: `packages/ui/package.json`
pins exact core 0.1.14 and `packages/ui/src/styles.css` imports it before local
extensions. Its current deployment/complete interaction coverage was not checked
in this audit. Treat further work as an upgrade and deeper adoption.

Waffler Registry, the main website and the music website currently load the legacy
`https://cdn.sywapps.com/css/syw.css` in their HTML entry points. They are existing
branding consumers awaiting migration to the immutable contract, not greenfield
applications. See [the migration queue and session prompts](consumer-migrations.md)
for evidence, first slices and ownership boundaries.

## CDN adoption checkpoint

Merged [syw-cdn#27](https://github.com/SYW-Apps/syw-cdn/pull/27) pins both core and React packages to immutable Design System 0.1.24 tarballs, with matching build-time version checks and HTML metadata. Production-image and publisher API CI verify the installed packages with React 19.3.0.

The [deployment run](https://github.com/SYW-Apps/syw-cdn/actions/runs/39301471442) rebuilt that image, recreated and started the manager container, and completed NGINX proxy-secret synchronization. This deployment evidence is separate from a live public/admin interactive smoke check.

The shared React browser fixture runs against React 18.3.1 and the CDN consumer's React 19.3.0. It checks the actual bundled React version before verifying tab/radio keyboard navigation, native page scrolling, disabled skipping, panel focus and parent/modifier event ownership. This coverage does not require a new public artifact release.

## Authentik adoption checkpoint

Completed in merged [syw-authentik-overlay#23](https://github.com/SYW-Apps/syw-authentik-overlay/pull/23), with image and browser CI validation:

- use native `<dialog>` with the `syw-dialog` structure for the Appearance Center;
- use `syw-field` compositions and shared button surfaces;
- complete keyboard behavior and panel relationships for segmented controls and tabs;
- remove obsolete private styles replaced by shared classes;
- keep Shadow DOM focus and reduced-motion rules explicit because this embedded consumer loads `components.css` without the document foundation reset.

Merged [syw-authentik-overlay#26](https://github.com/SYW-Apps/syw-authentik-overlay/pull/26) consumes Design System 0.1.22 and removes the palette editor's private invalid-border rule. Invalid hex values use shared `syw-input` and `syw-field__error` styling with linked error text. Consumer logic owns validation timing, storage and clearing errors when either the text input or native picker repairs the value. Derived-image and Chromium CI passed against the exact bundled release, including both recovery paths.

Merged [syw-authentik-overlay#27](https://github.com/SYW-Apps/syw-authentik-overlay/pull/27) consumes Design System 0.1.23 and preserves modifier shortcuts and parent-cancelled keyboard events. Derived-image and Chromium CI passed against that exact bundled release.

Merged [syw-authentik-overlay#28](https://github.com/SYW-Apps/syw-authentik-overlay/pull/28) fixes login flows that force ShadyDOM. It prepares both bundled stylesheets as inline template styles, uses the existing ShadyCSS API, and runs the complete consumer suite in both native and forced compatibility modes. The regression reproduced missing control sizes without Brand CSS; the fix needs no skin replacement.

Overlay 0.2.8 is deployed as `2026.8.4-ds0.1.23-ov0.2.8` through [server-stacks#38](https://github.com/SYW-Apps/syw-apps-server-stacks/pull/38). The [deployment run](https://github.com/SYW-Apps/syw-apps-server-stacks/actions/runs/39309555312) completed database backup, server/worker health checks and payload verification. Live signed-out login verification confirmed 34px mode controls, 42px tabs/close control, keyboard tab switching and focus restoration. The signed-in dashboard/Admin matrix remains a separate check; do not infer it from the anonymous flow test.

The 0.1.21 structural skin was applied to Brand Custom CSS, and the user confirmed the user-switcher dropdown and command palette render correctly. That skin is unchanged in 0.1.23. Brand CSS and the overlay's bundled release pin are independent: rebuilding the image does not update the saved Brand field.

The Deploy Authentik action applies the repository Compose file explicitly while using `/srv/stacks/authentik` for environment values and relative mounts. This deployment path does not require that host directory to track the repository; its local Compose copy can be older than the running deployment.

Theme swatches, palette editing and the viewport launcher remain consumer patterns until another concrete consumer demonstrates a shared requirement. SYW Accounts persistence remains deferred.
