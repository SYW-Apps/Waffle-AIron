# Design catalogue

A future `design.sywapps.com` should be the human and machine-discoverable catalogue for the system, not just a marketing docs page.

The structural source-of-truth registry for currently supported CSS components, shells and recipes is `catalogue/catalogue.v1.json`. Copyable React examples live in `catalogue/examples.v1.json`. Interaction examples in `examples/catalogue/interactions.js` supply both the live demo handlers and generated `exampleJavaScript` text, so the copyable code follows the implementation. These are catalogue examples, not automatic core runtime behaviour.

Usage guidance lives in `catalogue/guidance.v1.json`, which defines reusable appearance-support profiles plus one accessibility note/profile assignment per catalogue item.

The release build merges both sources into one enriched `catalogue.json`, so catalogue sites and developer/AI tooling consume a single immutable contract alongside the exact CSS version they describe.

CI validates the catalogue against `components.css`, `shells.css` and `recipes.css` in both directions:

- every public `.syw-*` CSS class must be represented by a catalogue item;
- every class referenced by the catalogue must exist in the public CSS contract;
- every catalogue item must have accessibility guidance and a valid support profile;
- guidance may not reference missing catalogue items;
- support profiles must use valid modes, densities, text sizes and motion semantics.

This prevents the catalogue and its guidance from silently drifting away from implementation.

## Release preview

`examples/catalogue/` is the first live consumer of the catalogue contract. The build publishes it under `dist/examples/catalogue/` next to the release artifacts it renders.

The preview intentionally does not own component metadata. It loads the generated `catalogue.json`, `themes/builtins.json` and sibling `manifest.json`, renders live HTML examples, exposes theme/mode/search/status/kind controls, and shows classes, semantic tokens, appearance support and accessibility guidance. The manifest version is displayed directly so the preview identifies the exact immutable release it is rendering even when reached through a floating alias such as `v0` or `latest`.

This makes it a useful prototype for `design.sywapps.com` while keeping the design-system release as the only external source of truth. When the dedicated catalogue application exists, it should consume an exact immutable Design System release in the same way; preview environments may opt into a floating alias while still displaying the resolved manifest version.

For every component/pattern/recipe the eventual site should show:

- live preview;
- semantic contract and customization tokens;
- accessibility notes;
- HTML/Jinja example;
- React example;
- MUI integration where relevant;
- supported themes/modes/densities/text sizes and motion behavior;
- status: experimental / stable / deprecated;
- introduced/deprecated versions.

The test matrix should cover theme × light/dark/high-contrast × cozy/compact × viewport, with visual regression and contrast/accessibility checks.

## Developer and agent entry points

Each release publishes `llms.txt` and its Markdown `docs/` beside the catalogue,
and includes them in the core tarball. Resolve an exact manifest before using
examples or installing packages. The catalogue's optional `exampleReact` and
`exampleJavaScript` fields are additive to schema version 1; consumers must not
assume every CSS item has a React wrapper or JavaScript handler.

The preview loads each built-in theme stylesheet, exposes theme/mode/density/
text-size/motion controls, and supports copyable HTML, JS and React examples.
Tabs, single-choice segmented controls and dialogs are interactive and keyboard
reachable. Copy HTML and JS together for the plain-HTML interaction examples;
React examples use controlled adapter APIs and consumer-owned panels/state.
The source HTML uses illustrative IDs; give repeated instances unique IDs.
