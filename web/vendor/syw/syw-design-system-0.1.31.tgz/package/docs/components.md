# Reusable components and interaction responsibilities

Use the exact [catalogue](../catalogue.json) and [live examples](../examples/catalogue/index.html)
with this guide. The catalogue contains HTML, standalone JavaScript where needed,
React examples, status and support profiles for the complete current CSS surface.
Do not infer exports or behavior from a component's name.

## React API map

| Export | Key props | Application responsibility |
| --- | --- | --- |
| `SywButton` | Native button props; `variant`: default/primary/danger/ghost | Action, submit type, loading/disabled state, permission decisions |
| `SywCard` | Native div attributes | Content semantics and product layout; use semantic native markup with `syw-card` when an article/section/link is needed |
| `SywShell` | `kind`: website/app/workspace/media/bare; native div props | Choose layout deliberately; supply header/sidebar/main structure and shell CSS |
| `SywSegmented` | `value`, `options: {value,label,disabled?}[]`, `onChange` | Controlled selection and the effect it has on the application |
| `SywTabs` | `value`, `tabs: {value,label,id,panelId,disabled?}[]`, `onChange` | Unique IDs, panels, visibility and optional vertical layout |
| `SywSetting` | `label`, `description?`, `control?`, `labelAs?` | Preference persistence; explicitly associate a native field label where needed |
| `SywEmptyState` | `title`, `description?`, `icon?`, `actions?`, `titleAs?` | Accurate state and useful recovery actions |

Adapters render the shared DOM/CSS contract. Native inputs, selects, textareas,
checkboxes/radios, links and dialogs remain native. The thin MUI adapter is a
separate semantic-variable mapping; see [MUI](mui.md).

## Fields and validation

Use `syw-field`, `syw-field__label`, `syw-field__help/error` with `syw-input`,
`syw-select` or `syw-textarea`. Keep persistent labels; placeholders are hints.
Associate label/input IDs and help/error descriptions. Native disabled and
read-only are different states. Apply `aria-invalid` only at the application's
chosen validation point. The library does not call APIs or choose validation rules.

## Buttons and navigation

Use a button for an action and an anchor for navigation. Specify `type="button"`
for non-submit actions inside forms. Native `disabled` prevents activation.
`aria-disabled` only describes state: applications retaining disabled actions in
the focus order must block pointer/keyboard activation themselves. Keep visible
focus; product hover/shadow rules must not overwrite the focus indicator.

## Tabs and segmented controls

React wrappers implement roving focus, wrapping, disabled skipping and selection.
Horizontal tabs own Left/Right; vertical tabs own Up/Down. Unowned arrows retain
native scrolling. Parent-cancelled events and Alt/Ctrl/Meta shortcuts remain with
the parent. Standalone segmented radio groups support all four arrows.

The application supplies the selected value and renders correct tab panels:
`role="tabpanel"`, matching IDs/`aria-labelledby`, hidden inactive panels and a
sensible panel focus target. Plain HTML consumers implement the interactions from
the catalogue's JavaScript example. Styling alone does not create a tab system.

## Dialogs

Use `<dialog class="syw-dialog">` with a name, visible close action and direct
`syw-dialog__header`, `syw-dialog__body`, `syw-dialog__footer` children. Open with
`showModal()`, not an `open` attribute intended to imitate modality. The body
scrolls while actions remain reachable. Test Escape, initial focus, close and
focus return; choose a stable target if the original invoker no longer exists.

## Status and data states

Use `syw-alert` and its success/warning/danger variants for messages, with title/
body classes. Choose `role="alert"` for errors requiring immediate announcement,
`role="status"` for polite progress, and avoid announcing the same unchanged text
repeatedly. Empty results are not loading or an API failure. Preserve current
retry/clear behavior and remove stale errors/results when appropriate.

## Themes, support profiles and extension boundaries

Read each catalogue item's support profile. Universal controls should follow
semantic colors and supported modes/density/motion. Expressive effects and
product canvas layouts may have a narrower documented scope. Contrast against
user colors still needs the [color module](color.md); a class is not a compliance
certificate. Keep product-specific graphs, node handles, media behavior and
custom-theme authoring data until a documented shared replacement covers them.

## App overlays

Tooltips, context menus and popovers have experimental semantic surface skins;
their interaction/positioning engine remains caller-owned. Dialog and toast
integration plus mandatory migration checks are in [the overlay guide](overlays.md).
