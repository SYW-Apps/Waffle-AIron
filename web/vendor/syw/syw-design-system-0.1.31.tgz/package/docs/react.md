# React adoption

React 18 and 19 use the same thin adapter and CSS contract. Start with the
[implementation workflow](implementation.md) and preserve the existing router,
authentication, theme/provider and state ownership.

## Install and import

```sh
npm install --save-exact https://cdn.sywapps.com/ui/0.1.31/packages/tarballs/syw-design-system-0.1.31.tgz https://cdn.sywapps.com/ui/0.1.31/packages/tarballs/syw-design-react-0.1.31.tgz
```

Commit the lockfile. These are install-time URL dependencies; choose verified
local vendoring/mirroring if required. See [distribution](distribution.md).

Import once in the existing application entry point, before app extensions:

```tsx
import '@syw/design-system/core.css';
import '@syw/design-system/components.css';
import '@syw/design-system/themes/waffler.css';
import './app.css';
```

Set the owning document's `data-theme="waffler"` and a valid `data-mode`. Import
`shells.css` or `recipes.css` only when their patterns are used. The adapter does
not inject styles or supply a provider; existing providers remain in place.

## A controlled form using the actual exports

```tsx
import { useId, useState } from 'react';
import { SywButton, SywCard } from '@syw/design-react';

export function ExampleSettings() {
  const id = useId();
  const [name, setName] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const invalid = submitted && !name.trim();
  return (
    <SywCard>
      <h1>Settings</h1>
      <form noValidate onSubmit={event => {
        event.preventDefault();
        setSubmitted(true);
        // Example only: retain the app's real validation and save operation.
      }}>
        <div className="syw-field">
          <label className="syw-field__label" htmlFor={id}>Display name</label>
          <input id={id} className="syw-input" value={name} required
            onChange={event => setName(event.target.value)}
            aria-invalid={invalid || undefined}
            aria-describedby={invalid ? `${id}-error` : undefined} />
          {invalid && <p id={`${id}-error`} className="syw-field__error" role="alert">Enter a display name.</p>}
        </div>
        <SywButton variant="primary" type="submit">Save</SywButton>
      </form>
    </SywCard>
  );
}
```

Inputs/selects/textareas are native elements with shared classes, not invented
React exports. For loading actions, the application owns the in-flight state and
sets native `disabled`; retain existing error recovery and announcements.

## Selection, settings, empty states and dialogs

Read [the component/API map](components.md). `SywSegmented` is controlled through
`value`, `options`, `onChange`; `SywTabs` takes `value`, `tabs`, `onChange` with
explicit IDs/panel IDs. The adapter owns selection keyboard navigation while the
application owns state and panel visibility. Copy the exact release's compiled
[React catalogue examples](../examples/catalogue/index.html), not an assumed API.

`SywSetting` takes `label`, optional `description` and `control`; it does not
invent a preference store. `SywEmptyState` takes `title`, optional description,
icon/actions and `titleAs`. Native dialogs compose with shared CSS; there is no
`SywDialog` component. Use `showModal()`, a ref and explicit focus-return handling
where the application replaces/removes its invoker.

## Theme and contrast integration

Keep saved appearance in the existing store. Apply document state through the
[appearance runtime](appearance-storage.md), and import helpers from
`@syw/design-system/color` when resolving dynamic accents. Calculate against the
actual surface and recompute when the relevant state changes. For DOM-computed
backgrounds, perform measurement after rendering rather than during render.
Do not delete a working resolver or custom theme builder when switching classes.
Read [color](color.md) and [theme-builder parity](theme-builder-parity.md).

For SSR applications, load the document-dependent appearance runtime through a
client-only dynamic import after the browser document exists. A top-level runtime
import in server code will access `document`; the pure color module has no such
restriction. Keep initial server/client appearance consistent during hydration.

## Migrate incrementally

Choose one existing flow, replace its duplicated generic controls and verify the
real behavior. Keep product composition and unique stateful UI local. Exclude
shared fields/buttons from broad legacy selectors before removing old styles.
Do not combine a React/router/MUI upgrade or new CI/deployment system with the
styling slice unless it is explicitly part of the application task.
