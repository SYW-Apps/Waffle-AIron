# Cross-app appearance storage

The design system defines the portable appearance contract. It does not own user accounts or persistence.

## Canonical ownership

For signed-in SYW users, **SYW Accounts** is the canonical store for:

- the user's appearance profile,
- user-created custom themes,
- optional per-application overrides,
- revision/update metadata used for synchronization.

Authentik remains the identity provider and should not be the canonical database for appearance settings. Authentik user attributes may later mirror a small compatibility value (for example a selected profile or theme identifier), but the source of truth stays in SYW Accounts.

## Appearance state

`schemas/appearance-state.v1.schema.json` is the portable snapshot exchanged between a canonical store and clients. It contains:

- `profile`: an `appearance-profile.v1` document;
- `customThemes`: the complete Theme v1 set owned by the user;
- `revision`: an opaque concurrency token;
- `updatedAt`: an informational server timestamp.

The revision is intentionally opaque. Clients compare it for equality only; they must not parse it, increment it or infer ordering from its contents. This keeps the contract compatible with integer revisions, hashes, UUIDs, ULIDs or storage-specific ETags.

Custom-theme IDs in `customThemes` must be unique. Every `kind: "custom"` theme reference in the profile or an app override must resolve to a theme in the same state. These are semantic invariants in addition to JSON Schema validation.

`examples/appearance-state.v1.json` provides a complete state containing a custom theme and an app-specific override.

### Recommended HTTP concurrency contract

A future SYW Accounts appearance resource should expose the state as a normal versioned HTTP resource:

```text
GET <appearance-resource>
  -> 200 + Appearance State v1
  -> ETag: "<revision>"

PUT <appearance-resource>
If-Match: "<revision>"
Body: complete desired Appearance State v1 snapshot
  -> 200 + canonical state with a new revision
  -> 412 Precondition Failed when the canonical revision changed
```

The exact route belongs to SYW Accounts, not the design system. The important contract is full-state replacement plus optimistic concurrency. A client that receives `412` fetches the newer canonical state and applies the product's explicit merge/conflict policy instead of silently overwriting another client.

`updatedAt` is useful for UI/history but is **not** a conflict-control mechanism. Clock skew and equal timestamps make last-write-wins-by-time unsuitable here.

The same contract works through a future same-origin Authentik bridge: the browser talks to a local `/syw-api/...` path, the reverse proxy authenticates it, and the bridge forwards the canonical state/ETag semantics to SYW Accounts.

## Client behavior

Clients use a local-first cache so appearance can be applied before a network round-trip and so desktop/offline applications continue to work:

1. Load the last validated Appearance State snapshot from local application storage immediately.
2. Install its custom themes and apply the resolved profile before or during first paint where the platform permits.
3. If the user is signed in and online, fetch the canonical state from SYW Accounts.
4. Compare revisions. When the canonical revision differs, validate and replace/reconcile the local snapshot, then apply it.
5. On edits, validate first and update the local cache immediately for responsive UI.
6. Persist the complete desired state with the last canonical revision as `If-Match`.
7. Replace the local revision with the canonical revision returned by the server.

For browsers the cache is normally `localStorage`/IndexedDB. Tauri or other native shells should use their normal local application store. A cookie may contain a small non-sensitive mode/theme hint when server-side rendering needs it, but cookies are not the custom-theme database.

A cache should preserve the last canonical revision so an offline edit can later attempt an optimistic write. Applications should make their conflict policy explicit rather than relying on whichever device reconnects last.

## Anonymous users

Anonymous users keep their preferences locally. They may use the same Appearance State shape with a client-owned local revision token, or store profile/themes separately if synchronization is not needed yet.

When an anonymous user later signs in, the application can offer to import the local custom theme/profile into SYW Accounts or merge it automatically under an explicit product policy. Once the canonical state is accepted, its server revision replaces the local-only revision.

## Safe custom themes

Custom themes are data conforming to `schemas/theme.v1.schema.json`; they are **not arbitrary CSS**.

Consumers must reject unknown keys and invalid values before applying a theme. This prevents a synced theme from becoming a CSS/HTML/script injection surface and makes the same theme portable across web, Tauri, Authentik adapters and future native clients.

Version 1 intentionally limits custom-theme content to semantic colors. Additional typed capabilities (for example radii, gradients or effect strengths) should be introduced additively in later schema versions rather than allowing free-form CSS strings.

### Browser runtime

Web consumers can use the framework-neutral runtime helpers for either individual custom themes or a complete synchronized Appearance State:

```js
import {
  applyAppearanceState,
  installCustomTheme,
  removeCustomTheme,
  validateAppearanceState,
  validateCustomTheme,
} from '@syw/design-system/runtime';

const validation = validateAppearanceState(state);
if (validation.valid) {
  applyAppearanceState(state, {
    appId: 'waffler',
    prefix: 'syw',
  });
}
```

`applyAppearanceState()` validates the complete snapshot, installs or updates all custom themes without activating them individually, resolves the optional `appOverrides[appId]`, and applies the resulting profile through the normal appearance runtime. It returns the applied revision plus resolved appearance values so callers can keep their cache/UI in sync.

Because Appearance State defines the complete synchronized custom-theme set, the helper also removes stale styles that were installed by a previous Appearance State application. It marks only state-managed generated styles and does not remove independently installed/local themes owned by other application code. Set `pruneStateThemes: false` when a consumer deliberately wants old state-managed styles to remain available during a transition.

Persistence and conflict resolution remain outside the runtime. The local cache/SYW Accounts client decides which validated state wins; `applyAppearanceState()` only applies the chosen snapshot. A `412` conflict must therefore be resolved before invoking the helper with the resulting canonical/merged state.

`installCustomTheme()` validates the Theme v1 object again, generates a controlled `<style>` element, and activates the theme ID by default. The user-supplied data only fills the semantic color variables defined by the schema. The design system derives gradients, elevation shadows, header glass and `color-scheme`; arbitrary CSS is never accepted.

Installing the same theme ID again updates its existing generated style element instead of adding duplicates. This is the intended path when a newer SYW Accounts revision arrives. `removeCustomTheme()` removes the generated style when a cached/custom theme is deleted.

Theme v1 requires light and dark palettes. `highContrast` remains optional; when it is absent, the browser runtime uses the dark semantic palette for high-contrast mode while disabling decorative elevation shadows. Applications that require a purpose-designed high-contrast palette can require `highContrast` before offering that mode for a custom theme.

Native consumers should implement the same schema validation and map semantic fields to their toolkit rather than evaluating the generated browser CSS.

## Appearance profiles

`schemas/appearance-profile.v1.schema.json` describes the user's portable preference axes:

- theme reference (built-in or custom),
- mode,
- density,
- text size,
- font,
- motion,
- optional per-application overrides.

A consumer may support only a subset. For example Authentik can consume palette/mode and accessibility-related choices while ignoring workspace layout or product-specific preferences.

## Authentik

The supported CSS adapter consumes the design system's semantic theme values. Authentik is not responsible for storing custom themes.

The deployed SYW Authentik overlay is an active consumer of the shared CSS, semantic tokens and portable theme/profile shapes. Its isolated appearance store owns the current local cache and Authentik theme bridge; it deliberately does not import the general browser runtime or write Authentik's native `data-theme` state. Authentication UI and backend remain upstream-owned.

SYW Accounts synchronization remains deferred. A future integration should adapt the overlay's existing local store to the canonical Appearance State/ETag contract rather than introduce Authentik attributes as another source of truth. See `docs/consumers.md` for adoption and deployment status.
