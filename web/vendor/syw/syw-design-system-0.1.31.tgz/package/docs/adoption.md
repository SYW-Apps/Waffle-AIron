# Adoption

For the complete cross-framework workflow, start with the
[implementation guide](implementation.md).

Start with the exact release's `manifest.json` and `packages/tarballs/index.json`.
For agents, read [the adoption workflow](agent-guide.md); `../llms.txt` provides
release-local discovery. The source placeholder `0.1.31` is resolved by the release build.

For dynamic product/user colors, use the independent [color and contrast tools](color.md).
Read the [theme-builder parity audit](theme-builder-parity.md) before replacing an
existing theme builder or converting richer saved themes. Projects own their
migrations and choose install-time CDN fetching or verified local vendoring.

## Static HTML / Jinja

```html
<link rel="stylesheet" href="https://cdn.sywapps.com/ui/0.1.31/syw.css">
<html data-theme="syw-apps" data-mode="dark" data-density="cozy">
```

The aggregate bundle includes the default SYW Apps theme. To select another
built-in theme, also load its exact-release `themes/waffler.css` or
`themes/neutral.css`, then set `data-theme` to that ID. For React, import the
same theme file from the installed core package.

Then use stable classes:

```html
<button class="syw-button syw-button--primary">Save</button>
<div class="syw-card">...</div>
```

## React products

Install matching exact core and React packages from the immutable tarball index.
For this built release:

```sh
npm install --save-exact https://cdn.sywapps.com/ui/0.1.31/packages/tarballs/syw-design-system-0.1.31.tgz https://cdn.sywapps.com/ui/0.1.31/packages/tarballs/syw-design-react-0.1.31.tgz
```

Commit the app's lockfile. These URLs require publication; a source PR alone does
not make them available. See [distribution](distribution.md) for package transport.


Install exact immutable core and React-adapter releases together. The adapter renders the same `.syw-*` DOM/CSS contract as plain HTML and does not own theme values.

```tsx
import '@syw/design-system/syw.css';
import {
  SywButton,
  SywSegmented,
  SywSetting,
} from '@syw/design-react';
```

`SywSegmented` is controlled through `value`, `options` and `onChange`; the adapter renders its items and handles keyboard navigation. For example, inside a React component with `view`/`setView` state:

```tsx
<SywSegmented
  aria-label="View"
  value={view}
  options={[
    { value: 'grid', label: 'Grid' },
    { value: 'list', label: 'List' },
  ]}
  onChange={(nextView) => setView(nextView)}
/>
```

Use the React adapter where it adds useful accessibility or composition defaults; continue using semantic HTML plus `.syw-*` classes for structures that do not benefit from a wrapper.

`SywTabs` owns arrows on the tablist's declared axis: Left/Right by default, or Up/Down for `aria-orientation="vertical"`. Other-axis arrows retain native scrolling. The standalone `SywSegmented` radio group supports all four arrows. Both wrappers respect parent-cancelled events and Alt/Ctrl/Meta shortcuts; consumers own panel visibility and any custom vertical layout.

## Existing React/MUI products

Adopt in stages:

1. load the token/theme layer;
2. replace hardcoded colours with semantic CSS variables;
3. use `@syw/design-react` for shared application primitives where it improves ergonomics or accessibility;
4. use the MUI adapter when MUI needs the same semantic values;
5. migrate shared chrome/components opportunistically;
6. remove legacy aliases only at a major-version migration.

## Tauri/offline

Pin an exact release and copy it into the app during build. Do not require CDN availability to render the local UI.

## Auto-updating first-party apps

The current major alias is `/ui/v0/...`; `/ui/latest/...` follows the latest published release. Use exact versions where change control matters more than automatic convergence, including Authentik and offline applications.

## Native dialogs

Use a native `<dialog class="syw-dialog">` and call `showModal()` for a modal. The platform owns modality, Escape dismissal and initial focus handling. Give it an accessible name and a visible close button; return focus to a stable invoker when closing if the original invoker was removed by a render.

Use `syw-dialog__header`, `syw-dialog__body` and `syw-dialog__footer` as direct children. The open dialog uses a constrained column layout: the body scrolls while header/footer remain reachable. Closed dialogs retain native hidden behavior. Consumer sizing or additional rows may override the open layout explicitly, as the Authentik Appearance Center does.

## Embedded Shadow DOM consumers

Loading only `components.css` avoids applying document-level resets to the host application. Supply the inherited foundation tokens and scope focus-visible, density, text-size and reduced-motion handling inside the shadow root. CSS classes supply presentation; the consumer must still implement radio/tab keyboard interaction and accessible names/relationships.

When a host forces ShadyDOM compatibility mode, fetch the bundled CSS into
inline template styles and call the host's existing ShadyCSS `prepareTemplate`
before stamping, then `styleElement`/`styleSubtree` as required after rendering.
External stylesheet links inside a shadow root are not shimmed. Authentik overlay
0.2.8 implements this path and tests both native and forced compatibility modes.

See [active consumers](consumers.md) for the current adoption inventory.

## Control states

Use native `disabled` on buttons, segmented options, tabs and form controls when they are unavailable. Core supplies a muted presentation, disabled cursor and suppression of hover feedback; the platform supplies disabled behavior. A disabled selected option retains its selection indication. Read-only fields remain a distinct, readable state and are not dimmed.

Button, segmented-item and tab classes also recognize `aria-disabled="true"` for consumers that deliberately keep unavailable actions in the focus order. ARIA alone does not prevent activation: the consumer must block pointer and keyboard activation while preserving the visible focus indication.

Set `aria-invalid="true"` on `syw-input`, `syw-select` or `syw-textarea` when application validation fails. Core uses the semantic danger border; provide a visible `syw-field__error`, connect it through `aria-describedby` and give actionable error text. Validation timing and error announcements remain application responsibilities; fields are not styled invalid merely because an untouched native constraint fails.
