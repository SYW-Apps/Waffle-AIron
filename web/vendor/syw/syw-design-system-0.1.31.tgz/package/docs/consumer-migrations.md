# Consumer migration queue and session prompts

Consumer audit: 19 October 2026; theme-builder follow-up: 20 October. These are
handoffs for the owning application sessions, not authorization for this session
to edit their repositories or claims of completed migration/live verification. Read current target instructions
and source again before editing; another session may have advanced the app.

The changes in this branch prepare **0.1.31**. Start a
consumer upgrade only after its exact CDN manifest, tarball index and guide are
published and verified. A merged source PR does not imply publication. Existing
consumers remain on their current pins until their own reviewed migration.

| Repository | Observed adoption | Recommended next slice | Suggested session |
| --- | --- | --- | --- |
| `syw-authentik-overlay` | Active exact 0.1.23; overlay 0.2.8 deployed and anonymous flow checked | Maintain native/compatibility-mode regression coverage; evaluate shared fixes when needed; preserve current pins during review | Owning overlay session |
| `syw-cdn` | Active exact 0.1.24 core/React packages; React 19 | Keep as reference consumer; update only for a needed shared change | Owning CDN session |
| `Traqolic` | `packages/ui/package.json` pins exact core 0.1.14; `packages/ui/src/styles.css` imports `syw.css` plus local extensions and a legacy bridge | Upgrade and reduce duplication in one existing settings/form flow; preserve shared UI and offline clients | App-focused handoff |
| `waffler-registry` | `web/index.html` loads legacy `/css/syw.css`; React 18; local `globals.css` maintains a parallel token/control vocabulary | Replace legacy runtime CSS with bundled exact assets, map local tokens, migrate package search/filter controls and empty/error presentation | Registry session owns review and migration |
| `www.sywapps.com` | `index.html` loads legacy CSS; React 18 and Material-UI 4; local theme/provider | Migrate one public landing section and its actions/cards; retain router/auth/provider and intentional scrolling | Website-focused handoff |
| `music.sywapps.com` | `index.html` loads legacy CSS; React 18 and MUI 7; hardcoded theme surfaces and playback-specific components | Exact bundled tokens plus one library/list surface; preserve player state, media controls and playback | App-focused handoff |
| `waffler-ui` | React 18 workspace library with sibling SDK dependency, custom designer styling and plugin surfaces | Inventory current theme ownership, then migrate one ordinary settings surface | Workspace-focused handoff |

Legacy stylesheet users are existing branding consumers. They have not yet been
verified as consumers of the immutable `/ui/<version>/` contract. Traqolic is an
existing versioned consumer, not a prospective new one. Waffler's theme-builder
source audit is linked in the handoff below; its complete stylesheet/host graph
and live app have not been tested here.

## Registry handoff

The Registry session owns evaluation of any existing PR and its CI changes.
Keep existing dynamic contrast calculations and package branding until a verified
replacement measures the actual rendered surface. Removing a contrast function
because shared tokens exist does not preserve that behavior. The [color module](color.md)
is available independently of CSS/React after its release is published.

Audit current source and the existing draft before choosing a migration slice.
Select installation via exact hash-pinned CDN tarballs, local verified vendoring
or an approved internal mirror explicitly; a tarball URL remains an install-time
external dependency. Reuse the application's normal CI and deployment process.
Preserve PWA/service-worker behavior, protocol handlers, publishing/authentication,
API and URL/history contracts. A new design-system release does not authorize
changes to those boundaries or require new infrastructure.

## Website handoff

The website's own session should audit current React/Material-UI/provider imports,
choose one public section and preserve router/authentication and normal document
scrolling. Use a published exact release's guide and catalogue, retain the local
lockfile, and keep existing theme/contrast behavior. Reuse its existing checks and
rollout. Ask this design-system session to resolve shared gaps encountered during
adoption instead of duplicating shared behavior locally.

## Traqolic handoff prompt

```text
Continue SYW-Apps/Traqolic as an existing SYW Design System consumer. Read all
repository instructions and current workspace state first. packages/ui currently
pins exact core 0.1.14 and imports it from packages/ui/src/styles.css, followed by
app extensions and a legacy bridge. Verify that state before editing.

After confirming the improved release is published, read its exact llms.txt,
docs/agent-guide.md, docs/adoption.md, catalogue.json and manifest.json. Upgrade
the core pin and pnpm lockfile deliberately; add the matching React adapter only
where its documented behaviour helps. Keep React 19, pnpm and the existing
@traqolic/ui boundary. Select one real settings/form flow and replace duplicated
generic controls with shared contracts, retaining product-specific layout.

Preserve appearance choices and storage, health/domain logic, API/auth contracts,
and web/Tauri/mobile behaviour. Bundle CSS into client builds; startup must work
without a live CDN. Verify workspace typechecks/builds, the selected flow's
keyboard/errors/responsive layouts and offline rendering. Return a focused PR
with exact versions, test evidence and remaining duplication; follow normal
app deployment practices. This does not authorize account-sync implementation.
```

## Music site handoff prompt

```text
Audit SYW-Apps/music.sywapps.com for incremental SYW Design System adoption.
Read current repository instructions, package/lockfile, index.html, src/index.tsx,
src/theme.ts, app providers and player state before editing. The audited source
used React 18, MUI 7 and the legacy CDN /css/syw.css; verify current state.

Read one published exact release's llms.txt, agent guide, adoption guide,
catalogue and manifest. Replace legacy runtime CSS with bundled exact assets.
Keep MUI 7 and current routing/authentication. The SYW MUI adapter exports semantic
variable mappings; it is not a drop-in theme/provider. Validate integration with
the current MUI APIs and colour processing before changing the provider.

Select one library/list surface for cards, actions, fields and existing empty
states. Keep playback, queue, media-session controls, volume/seeking, persistence,
API calls and authentication behaviour intact. Preserve the intended product
theme and allow shared semantic values to follow supported appearance modes.
Run build/lint and relevant tests plus a player regression smoke check in the
project's supported mock/live setup. Return a focused PR with evidence, remaining
gaps and normal rollout steps; do not combine a player rewrite or framework upgrade.
```

## Waffler workspace handoff prompt

```text
Audit SYW-Apps/waffler-ui in its working Waffler workspace. Read repository and
workspace instructions, the sibling @waffler/ui-sdk dependency, host theme setup,
src/app/styles and plugin styling boundaries before editing. Do not assume this
standalone repository can reproduce the complete application build.

Read one published exact SYW Design System release's llms.txt, agent guide,
catalogue and manifest. Inventory existing imports and theme ownership. Read
docs/theme-builder-parity.md and docs/color.md from the chosen release. Retain the full existing theme builder,
mode overrides, generated contrast sets, custom-theme metadata, image assets and
preference persistence: the portable v1 palette is not a lossless replacement.
Pin core/React assets only where the named slice can adopt them without losing
those capabilities; choose install-time CDN fetching or verified local vendoring.
Keep React 18 and local workspace dependency resolution. Migrate one ordinary settings panel's generic controls,
fields and empty/error states using documented contracts.

Preserve workspace scrolling, docking, designer/ReactFlow/Monaco behaviour,
canvas performance overrides, keyboard shortcuts, plugins, SDK public APIs,
preferences and core-gateway contracts. Keep product node/canvas styles local.
Verify workspace typechecks, relevant tests and that settings plus the main
designer still work at desktop/narrow layouts and with reduced motion. Return
a focused PR through the owning workspace session, exact versions and observed
verification limits. Propose shared gaps upstream instead of inventing parallel generic controls.
```

SYW Accounts remains deferred. Backend-only services and SDKs do not become UI
consumers merely because they belong to SYW Apps. Review this queue as each real
surface migrates, and record source/CI/deployment/live evidence separately.
