# Portable pill and condition editing

**Status: experimental, headless editing only.** This module supplies immutable
editing operations, not a DOM/contenteditable implementation, React input,
visual condition builder, evaluator or skin. Waffler remains the compatibility
reference and its owning session controls adoption. See [coverage](scope-and-coverage.md).

Install the exact [forms-core package](forms-core.md), then opt into its independent
subpath:

```js
import { createPillEditor, pillTarget, editPillExpression } from '@syw/forms-core/editing';
// Direct browser/module-worker alternative:
// https://cdn.sywapps.com/ui/0.1.31/packages/forms-core/editing/index.js

let editor = createPillEditor('Hello {{vars.name}}; {{vars.name}}');
const target = pillTarget(editor, 1); // second pill, even when raw text repeats
const result = editPillExpression(editor, {
  type: 'replace-pill', target, text: '{{vars.nickname}}',
});
if (result.kind === 'changed') editor = result.state;
```

There are no runtime dependencies, styles, framework, DOM, stores or registry
clients. The relative import graph loads expression computation but not the root
form runtime. Package declarations include optional host interfaces without DOM
types. Plain HTML, React and other renderers share these operations; each renderer
must implement and verify its own actual selection and input behavior.

## Source fidelity and atomic selection

`readPillDocument(value, {isFunction})` returns ordered source segments, covering
the exact original string with `start`/`end` UTF-16 offsets, `raw` and a compatibility
parser `token`. `pillIndex` counts only non-literal top-level tokens. The token may
normalize convenience keywords internally; use **segment.raw**, never its token's
raw or display label, for copying/editing the authored string. Untouched text,
escapes, newlines and `{{true}}` spellings remain byte-for-byte unchanged.

`normalizePillSelection` keeps backward ranges, expands partial pill selections to
whole pills and snaps a caret inside a pill to its nearer edge (ties go right).
It also prevents splitting a UTF-16 surrogate pair. Selection positions refer to
the source string, not displayed pill-label character counts or DOM child indices.

`editPillExpression(state, command, tokenizeOptions)` returns `changed`, `unchanged`,
`blocked` or `rejected`, always with the resulting `state`. It does not mutate
inputs, call providers or write externally. Commands include:

| Command | Effect |
| --- | --- |
| `select` | Update a source selection, including while read-only |
| `insert`, `paste` | Replace selection with raw text; never interpret clipboard HTML |
| `cut` | Return exact selected `clipboard` text and remove the selection |
| `delete` | Backward/forward whole-pill deletion or one Unicode grapheme in text |
| `enter` | Insert `\n` only in multiline mode; otherwise reject `single-line` |
| `replace-pill` | Replace/delete exactly one occurrence addressed by target |
| `move-pill` | Move that occurrence within the same source; dropping onto itself is a no-op |
| `apply-method` | Build Waffler's bare-argument `{{method(receiver)}}`; optionally consume the matching immediate `.query` |

`copyPillSelection` works while locked. Read-only/disabled states block every
mutating command. Configure host flags by retaining the state and replacing the
appropriate flag; use `createPillEditor` for an intentional external-value reset.
Always pass the same function classification options to parsing and editing.
`Intl.Segmenter` is required for grapheme deletion. IME composition, undo/redo,
focus, DOM selection transport and native key/clipboard event handling remain
renderer responsibilities. Single-line mode blocks Enter; pasted raw newlines
are retained, matching the source-value contract rather than silently deleting text.

Targets carry the document revision, occurrence and source raw. They are bound
to the editor that created them and reject stale changes. Selection-only changes
do not advance the document revision. Use the optional `revision` on insertion,
deletion and raw-expression commands when applying asynchronous host results.
Do not reuse an old target after editing or swap it between editor instances.

`transferPill(source, destination, target, options)` computes a cross-input move
or copy and returns both states together. Apply the pair atomically in the host;
there are no global move events or partial source writes. A move requires both
editors to permit writes; copying may read a read-only source. Same-input movement
uses `move-pill`. Persistence transactions and asynchronous conflict handling
belong to the host.

## Structured conditions without implicit loss

```js
import { createConditionEditor, emptyCondition, editCondition } from '@syw/forms-core/editing';
let state = createConditionEditor(emptyCondition());
const result = editCondition(state, {
  type: 'operand-text', target: {path: [], revision: state.revision},
  side: 'left_value', value: '{{vars.enabled}}',
});
if (result.kind === 'changed') state = result.state;
```

Condition paths are arrays of child indices; `[]` is the root. Every structured
edit needs a current revision target. Operators/empty rows/add-group defaults
follow Waffler's source. `conditionOperators` lists its 15 visual-editor choices;
the [form condition evaluator](forms-core.md) supports a different, wider set.
`conditionRequiresValue` hides the right input for the four unary choices without
erasing its saved wrapper.

Operations are `replace`, `remove`, `operator`, `operand`, `operand-text`,
`add-row`, `add-group`, `wrap` and `unwrap`. Added groups start as AND with one
empty mapped row. Removing the last child leaves an empty group. `unwrap` keeps
one child (or an empty row for an empty group); multiple children require explicit
`discardOthers: true` and may select `keepIndex`. Nested `replace` cannot clear a
child implicitly; use `remove`. InputValue wrappers and extra annotations on
untouched nodes are retained. `operand-text` changes the text and `mapped: true`
while preserving existing wrapper/metadata annotations; `operand` intentionally
replaces the complete wrapper supplied by the caller. Inputs must be acyclic
condition trees with own properties and wrapped operands.

`mode` switches between builder and expression views. A view-only round trip
retains the original tree, including unary right operands, single-child/empty
groups and annotations that expression syntax cannot encode. `expression`
commands retain raw text, including invalid/incomplete input, without silently
replacing the cached condition tree. `inspectConditionEditor` exposes its state:
cached tree, empty text, editable conversion or opaque expression.

After changing raw text, switching back requires the [conservative expression
inspection](expressions.md) to reproduce the entire string exactly. Unsupported
children, extra arguments or formatting changes reject conversion and retain the
text. If the previous tree also contains annotations/metadata that conversion
would discard, conversion rejects `would-discard-metadata`. A host may explicitly
use `discardMetadata: true` after its own user-facing decision; the module never
guesses where annotations should move in a rewritten tree. Keep the original
snapshot if offering recovery. This is a new loss guard, not a claim that Waffler's
current visual implementation already behaves this way.

## Host and renderer responsibilities

The optional TypeScript `ExpressionEditorHost` describes function classification,
manifest display lookup, strict variable resolution, suggestions, method choices,
function/access configuration and draft status. Callers supply field/local context,
source revision, request ID and optional numeric anchor rectangle. Unresolved and
out-of-scope variables are explicit; never manufacture a healthy fallback schema.
Callbacks have no default implementation. Drop stale asynchronous replies using
both request ID and revision; cancel obsolete requests in the host.

A renderer must supply labels, keyboard/pointer and screen-reader behavior,
composition handling, visible pill selection and focus restoration. Bind `raw`
as text/data, not unchecked HTML. Preserve the full `InputValue` outside this raw
string model. Suggestions, context actions and configuration panels must use
[themed overlay surfaces](overlays.md), including when portaled outside the editor.
There is no Waffler service/store dependency and no expression execution.

## Evidence and remaining gate

Exact source snapshots of Waffler `AlwaysPillInput.tsx` and `ConditionBuilder.tsx`
at `ff028e92d945b64de7ea98dea2bd66c7c3beaf6c` are SHA-256/Git-blob pinned. Tests
execute the original pure group-event closures and method-construction statements
as differential references. Source-preservation, duplicate occurrence, Unicode,
atomic selection, clipboard, moves, stale targets, locks, nested trees and loss
guards have independent cases. Actual packed offline npm imports, strict existing
models, browser/module workers and absence of styles/framework/root form runtime
are checked separately. These checks do not establish Waffler DOM interaction,
visual, accessibility or complete editor parity. Those remain renderer gates.
