# Portable form computation and builder operations

**Status: experimental.** This is the first extracted form module, not a shared
visual form generator or builder yet. It preserves the existing Waffler UI
schema/value shape and computation at the reference commit, with the explicit
own-property protections below. Read [scope and coverage](scope-and-coverage.md)
for the remaining renderer, builder-template, pill, condition-editor and canvas work.

## Install independently

```sh
npm install --save-exact https://cdn.sywapps.com/ui/0.1.31/packages/tarballs/syw-forms-core-0.1.31.tgz
```

The release's [tarball index](../packages/tarballs/index.json) includes `formsCore`.
Verify the [manifest](../manifest.json) hash and retain the lockfile. Installation
fetches this tarball; bundling/vendoring is the application's responsibility.
No React, CSS or design-system package is needed to use the computation.

Browser/worker ESM can import the independent module graph directly:

```js
import { validateForm } from 'https://cdn.sywapps.com/ui/0.1.31/packages/forms-core/index.js';
```

Its relative imports belong to that same exact release. Bundle/copy the complete
module graph for offline use; copying `index.js` alone is not sufficient.

## Keep the existing JSON and values

```js
import { seedFormDefaults, validateForm, updateLiteralValue } from '@syw/forms-core';

const schema = JSON.parse(existingSchemaJSON);
let values = seedFormDefaults(schema, existingValues);
values = {...values, title: updateLiteralValue(values.title, 'Updated title')};
const result = validateForm(schema, values);
// The application renders result.errors and decides when/how submission runs.
```

Definitions retain `key`, `label`, `type`, `ui`, `constraints`, `default_value`,
optional wizards and application annotations. Values retain `value` plus
`metadata.mapped`, type/source hints and the optional Boolean condition-builder
mode. There is no new JSON-schema conversion or serialization format.
The module accepts a `fields` envelope, a single field, or an Object-root field.
Reference/type resolution and legacy-kind normalization remain at the host's
existing boundary; reading a schema does not invoke services or erase annotations.

`seedFormDefaults` seeds only missing/undefined top-level entries with non-null
authored defaults, preserving existing entries. It adds `mapped:false` and
`source:'default'` for raw defaults and retains existing wrapped defaults.
It returns the original record if no patch is needed. It does not recursively
initialize arbitrary referenced types or wizard state. `getDefaultValue` exposes
the current per-kind render fallback separately from persisted default seeding.

`partitionFormFields` keeps declaration order and consecutive group sections,
including distinct sections when the same group name recurs later.

## Conditions, validation and value modes

- `evaluateCondition` / `evaluateConditionGroup` implement the reference's
  equality, ordered/date, Boolean, empty/existence, string/list, regex, range and
  JSON-check operators, including recursive AND/OR groups.
- `evaluateShowIf` is the pure computation used by a renderer's lifecycle or hook.
  An absent condition means visible. No React hook is required by this package.
- `readFormPath` reads dotted/bracketed own properties and unwraps nested
  InputValues; it does not evaluate Waffler expression strings.
- `validateField` / `validateForm` retain reference error strings, required/default,
  conditional visibility, literal numeric/string bounds, validation rules and
  concrete nested object/array handling. Null bounds from decoded wire data remain
  unset. Errors use the existing dotted/bracketed field paths.
- `updateLiteralValue` preserves auxiliary metadata, exits mapped/condition-builder
  mode and marks an existing source as `user`. Additional wrapper annotations survive.
- `toggleMapping(kind, value)` preserves auxiliary metadata and matches the
  reference conversions. In particular, switching structured values between modes
  resets their payload as Waffler currently does. Keep the existing UI's mode policy.

Value operations are not permission checks. The host enforces read-only, disabled,
mappable and action policy. Expression execution, async options, secrets, type
registries, overlay placement and application persistence stay with injected host
services in the future renderer/controller adapters.

## Expression computation without the editor UI

The opt-in [expression subpath](expressions.md) preserves Waffler token parsing,
argument serialization, display-text formatting and condition translation without
loading the root form runtime. Keep its original raw text, metadata and conversion
limits explicit; the guide documents a conservative editor-preservation boundary.
The opt-in [editing subpath](input-editing.md) supplies atomic pill and nested
condition operations. These modules do not execute expressions or supply a visual editor.

## Builder operations without the visual builder

```js
import { FormBuilder } from '@syw/forms-core';
const builder = new FormBuilder();
let fields = builder.addField(existingSchema.fields);
fields = builder.reorderField(fields, fields.length - 1, 0);
const json = JSON.stringify({...existingSchema, fields});
```

The pure API matches Waffler's `src/schema/form-builder.ts`: fresh field lists,
unused `field_N` keys, immutable remove/reorder, and keyed edits through nested
Object fields. Preserve the schema envelope, wizards, layout and host annotations
when saving. This API is a foundation for the visual schema builder template;
it does not supply the existing builder's settings panels, editor UI or providers.

## Compatibility evidence and limits

Pinned source: [Waffler UI ff028e92](https://github.com/SYW-Apps/waffler-ui/tree/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c).
The repository retains hash-checked source snapshots and unchanged upstream
validation, condition and pure-builder tests. Those tests run against the extracted
implementation. Differential tests compare conditions and validation, plus actual
inline defaults/grouping/value-transition functions extracted from the reference
React source. Package checks exercise independent Node/browser/worker imports and
TypeScript interoperation with an existing Waffler-shaped model.

Own-property protections intentionally reject inherited path segments and preserve
`__proto__` as an ordinary default/error key. They do not rename authored keys.
All other tested reference behavior is preserved; this is not a promise of parity
with unextracted renderers, schemas from a newer producer, or the live Waffler app.

Known inherited semantics remain explicit: unresolved left condition paths fall
back to literals; mapped values skip literal constraints; invalid authored regex
rules are ignored/logged as in the reference. Static `ui.hidden` does not itself
suppress validation; a condition-hidden parent can still produce nested errors.
The validator handles the reference's concrete nested object/array cases, not a
general recursive JSON-schema language or arrays-of-arrays. These behaviors need
separate reviewed changes and compatibility profiles before a consumer migration
should depend on different semantics. Treat schema definitions as trusted app
configuration: there are no complexity limits for hostile regexes or recursion.

The next extraction steps are the pill/condition editing controllers and host
interfaces, visual renderer and full builder template, and SYW/alternate skins. Keep
Waffler's existing UI and behavior while those steps are verified. The design
system adapts to the reference application; the application should not be reduced
to the currently implemented shared subset.
