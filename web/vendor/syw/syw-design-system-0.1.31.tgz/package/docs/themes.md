# Theme architecture

Built-in themes and user-defined themes share the same semantic color vocabulary, but they have different trust and capability boundaries.

## Built-in themes

The source of truth for first-party themes is `themes/builtins/*.json`.

Each built-in definition contains:

- identity (`id`, display name, default flag);
- raw brand primitives;
- semantic values for light, dark and high-contrast modes;
- first-party presentation tokens such as the primary gradient, surface shadows and header background.

`node scripts/generate-themes.mjs` renders the checked-in `themes/*.css` files. Those CSS files are generated artifacts for review and package compatibility; do not edit them directly.

CI runs `npm run check:themes` and fails when a generated CSS file does not match its structured definition.

The distribution build renders from the JSON definitions directly and publishes:

- `themes/<id>.css` for CSS consumers;
- `themes/builtins.json` for catalogues, tooling and other machine-readable consumers.

The aggregate `syw.css` embeds the theme marked `default: true`.

## Portable custom themes

Custom/user themes continue to use `schemas/theme.v1.schema.json`.

That contract is currently narrower than the built-in format. It contains safe semantic colors and does not accept arbitrary CSS, gradients, shadows or first-party implementation details. This is a capability gap for full theme authoring. Consumers must retain their richer builder and saved data; the v1 palette is not a lossless transport for those features. See the [Waffler parity audit](theme-builder-parity.md) and [portable color tools](color.md).

A richer shared authoring contract needs explicit effects, mode overrides and asset references, with optional product extensions and a deliberate compiler/runtime boundary. Do not loosen the existing v1 validator to accept arbitrary CSS or silently discard unsupported fields.

## Change workflow

To change a built-in theme:

1. edit its file under `themes/builtins/`;
2. run `npm run generate:themes`;
3. review both the data change and generated CSS diff;
4. run `npm run check:themes` and `npm run build`.

Applications should continue consuming released CSS artifacts rather than source JSON unless they specifically need machine-readable theme metadata.

## Contrast regression scope

The portable color tools measure explicit color pairs, and the built-in test
matrix now checks text/muted/primary on canvas/surface/raised surfaces, solid
primary/danger action labels, and 1,001 encoded-sRGB samples of each current
primary gradient. Version 0.1.31 corrects failing primary/link/action values
in Neutral and Waffler and the light SYW Apps gradient. Raw brand colors remain
available; readable variants are used where a text/control pair needs them.

These are regression checks for named built-in roles, not a guarantee for all
compositions, all rendering/interpolation paths or arbitrary custom palettes.
Validate actual component states and backgrounds. The current v1 custom-theme
validator checks the data shape/color syntax; it does not repair or certify its
contrast. Theme authoring still needs the derivation and validation work recorded
in [the parity audit](theme-builder-parity.md).
