# HTML and server-rendered templates

Read the [implementation workflow](implementation.md) first. No framework adapter
is needed. The same markup works in Jinja or another server template when the
server renders accessible values and state.

## A complete document

```html
<!doctype html>
<html lang="en" data-theme="waffler" data-mode="dark" data-density="cozy">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Example settings</title>
  <link rel="stylesheet" href="https://cdn.sywapps.com/ui/0.1.31/core.css">
  <link rel="stylesheet" href="https://cdn.sywapps.com/ui/0.1.31/components.css">
  <link rel="stylesheet" href="https://cdn.sywapps.com/ui/0.1.31/themes/waffler.css">
</head>
<body>
  <main class="syw-card" style="max-width:40rem;margin:2rem auto;padding:1.5rem">
    <h1>Settings</h1>
    <form id="settings-form">
      <div class="syw-field">
        <label class="syw-field__label" for="display-name">Display name</label>
        <input class="syw-input" id="display-name" name="displayName"
          aria-describedby="display-name-help" autocomplete="nickname" required>
        <p class="syw-field__help" id="display-name-help">Shown to other users.</p>
      </div>
      <button class="syw-button syw-button--primary" type="submit">Save</button>
    </form>
    <p id="save-status" role="status"></p>
  </main>
  <script type="module">
    const form = document.querySelector('#settings-form');
    form.addEventListener('submit', event => {
      event.preventDefault();
      // Example presentation only. Keep the application's real validation/API.
      document.querySelector('#save-status').textContent = 'Example form submitted.';
    });
  </script>
</body>
</html>
```

For a direct CDN integration those CSS URLs are runtime dependencies. For a
bundled server/static build, copy verified exact assets into its static directory
and change the links to those local URLs. `syw.css` is an alternative aggregate;
do not load it in addition to the same explicit layers.

## Template state and interaction

Use actual `disabled` attributes for unavailable native buttons/fields. Render
invalid state only according to the application's validation timing, with
`aria-invalid="true"`, visible error text and `aria-describedby`.
Escape user values using the template engine's normal escaping. A CSS class is
not a sanitizer and does not change the application's data handling.

Use normal anchors for navigation and buttons for actions. Use native checkboxes,
radios and selects where they fit. For tabs/segmented controls, read the
[catalogue's HTML and JavaScript together](../examples/catalogue/index.html):
implement roving focus, selection and panel visibility rather than styling
ordinary buttons and assuming the behavior exists. See [components](components.md).

## Dynamic product accents

```js
import { resolveAccessibleColor } from 'https://cdn.sywapps.com/ui/0.1.31/color.js';
const surface = document.querySelector('.syw-card');
const label = surface.querySelector('h1');
function refreshAccent() {
  const background = getComputedStyle(surface).backgroundColor;
  const result = resolveAccessibleColor('#8b5cf6', background, 4.5);
  if (result.meetsTarget) label.style.color = result.color;
}
refreshAccent();
// Call again from the application's theme/surface/color-change handler.
```

This example uses an opaque card surface. For transparency, provide the actual
underlay; for gradients/images, use a measured background treatment. The module
does not watch the document or certify a whole page. See [color tools](color.md).
