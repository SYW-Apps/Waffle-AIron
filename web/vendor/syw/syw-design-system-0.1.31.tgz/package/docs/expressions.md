# Expression tokens and condition translation

**Status: experimental.** This is portable computation extracted from Waffler UI,
not the expression pill editor, condition-builder UI, form renderer or visual
schema builder. Read [scope and coverage](scope-and-coverage.md) before migration.
Waffler remains the compatibility reference; its owning session controls adoption.
For source-preserving edit operations and host contracts, see [input editing](input-editing.md).

## Independent package and direct ESM

Install the same standalone forms-core tarball described in [forms core](forms-core.md):

```sh
npm install --save-exact https://cdn.sywapps.com/ui/0.1.31/packages/tarballs/syw-forms-core-0.1.31.tgz
```

Use the opt-in subpath; importing it does not load the root form computation:

```js
import {
  tokenizeExpression, reconstructExpression, getTokenDisplay,
  inputValueToArg, argToInputValue, inspectConditionExpression,
} from '@syw/forms-core/expression';
```

Browsers and module workers can import the exact-release graph directly:

```js
import { tokenizeExpression } from
  'https://cdn.sywapps.com/ui/0.1.31/packages/forms-core/expression/index.js';
```

There are no runtime dependencies, React, DOM, stylesheet, storage, registry
client or expression evaluator. The caller supplies optional function-registry
and display-manifest lookups. Verify the release [manifest](../manifest.json)
and lock integrity. Bundle/vendor the complete relative module graph for offline
use; retain the whole package for its TypeScript declarations as well.
The CDN tarball is an install-time download until the application bundles it.

## Preserve the existing token and expression shape

```js
const parsed = tokenizeExpression('Hello {{vars.name}}', {
  isFunction: name => knownFunctionNames.has(name),
});
const original = parsed.raw;
const serialized = reconstructExpression(parsed.tokens);
```

The existing discriminated token JSON is retained: literal, variable, function,
keyword, operator and bracket tokens carry their source `raw`. Variable tokens
retain scope/path; functions retain nested token-array arguments and invocation
versus reference mode. A known bare `{{name}}` can become a function-reference
pill through the injected lookup. Nested bare function calls retain their bare
raw representation inside argument lists.

Keep the original expression when merely opening/closing an editor. The upstream
parser normalizes convenience aliases such as `{{true}}` to
`{{default.true}}` before tokenization, including occurrences inside larger
strings. `ParsedExpression.raw` retains the original input; reconstructing tokens
can reflect that normalization. This extraction does not silently change it or
promise byte identity for every tokenizer/reconstruction cycle.

`buildFunctionRefToken` and `buildFunctionInvokeToken` retain the existing
constructors. The invoke constructor stores supplied argument text in `raw` and
empty placeholder arrays in `args`; tokenize its raw text when populated argument
tokens are needed. This source behavior is deliberately preserved.

## Argument serialization and escaping

`inputValueToArg` and `argToInputValue` implement the existing wrapped
`InputValue` conventions. Static scalars/quoted strings, mapped paths, complete
pills, nested invocations and mixed templates retain the reference conversions.
A nested call is wrapped back into a pill on decode so subsequent serialization
does not escape it into literal text.

`escapeForContext` takes the caller's structural delimiter set.
`unescapeTemplate` interprets the supported template escapes; unknown targets
remain literal. Tokens retain escapes for storage, while a panel may need the
interpreted value. An empty delimiter now throws `RangeError`: it cannot advance
the upstream scanner and would otherwise loop forever.

These helpers serialize expression arguments, not arbitrary JSON metadata.
Object/array literals are JSON-encoded into quoted string arguments; decoding
does not restore them as object/array values. `argToInputValue` creates mapped
metadata only. The host retains auxiliary wrapper metadata, schema annotations,
mode flags and the original expression alongside the editor state. It owns
read-only/mappable policy, provider resolution and actual expression execution.

## Condition conversion and the preservation boundary

The compatibility exports `conditionToExpression`, `expressionToCondition`
and `isConditionExpression` retain the source translator. Nested AND/OR groups,
four unary operators and eleven binary operators use Waffler's function syntax:

| Kind | Recognized operators |
| --- | --- |
| Unary | isEmpty, isNotEmpty, isTrue, isFalse |
| Binary | equals, notEquals, greaterThan, greaterThanOrEqual, lessThan, lessThanOrEqual, contains, startsWith, endsWith, regexMatch, regexNotMatch |
| Group | and, or |

This is narrower than the structured condition evaluator in forms core.
Serialization can write an operator name that the compatibility parser does not
recognize. Recognition is not expression validation or proof of runtime support.

**The upstream parser is permissive:** it can omit unsupported children of a
mixed group, ignore extra operands and collapse groups. Quoting, literal values
and whitespace may normalize on serialization. Never use
`isConditionExpression` alone to decide that a structured editor can safely
replace an existing expression.

Use the additive conservative inspection boundary:

```js
const opened = inspectConditionExpression(existingInput.value);
if (opened.kind === 'editable') {
  // Seed a controlled condition editor with opened.condition.
  // Write a new expression only after an explicit, permitted user edit.
} else {
  // Retain opened.expression exactly in the existing raw/pill editor.
  // No truncated condition candidate is exposed by this result.
}
```

An editable result means the compatibility parser and serializer reproduce the
input string exactly. An opaque result keeps every original byte, with reason
`unsupported` or `would-change-expression`. This deliberately also rejects
harmless normalization: `{{equals(a,b)}}`, alternate quotes, extra spaces and
single-child group wrappers can remain opaque. It is an opt-in preservation
guard, not a second language grammar, full validity check or UI mode mandate.
Existing consumers can keep their compatibility conversion while reviewing a
safer editor boundary explicitly.

## Display text without styling or UI providers

`getTokenDisplay`, `getTokenLabel`, `summarizeToken` and
`summarizeExpression` retain the source's pill-format, self/method, nested wrapping,
summary and truncation conventions. Variadic infix formatting retains all
operands. Supply the existing function manifest's `ui.pill_format`,
`ui.wrap_nested` and argument/self shape through a lookup.

Render these outputs as text, not HTML. They are display summaries, never a
replacement for the raw expression in storage. Colors, icons, contrast,
caret/selection/copy/paste behavior, suggestions, overlays and input appearance
remain outside this module. In particular `getTokenColor` and `getTokenIcon`
are not exported; no Waffler UI styling is removed or replaced by this extraction.

## Evidence and remaining work

Pinned source: [Waffler UI ff028e92](https://github.com/SYW-Apps/waffler-ui/tree/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c).
Hash-checked source/tests and a regeneration check keep the extraction reviewable.
Differential tests exercise the actual reference modules. The six unchanged
upstream test files run against production exports; their one cosmetic color
assertion is explicitly skipped because styling was not extracted.

Package checks install the actual tarball offline, resolve the package subpath
and strict existing-model TypeScript declarations without DOM types, and import
the independent ESM graph in Node, a browser and module workers.

The pill editor/controller, provider interfaces, condition editor, visual form
renderer, full schema-builder template and independent skins remain to be
extracted and verified. Rich theme authoring, reusable component/canvas profiles
and canvas adapters also remain in the [coverage plan](scope-and-coverage.md).
Do not replace richer application features with this currently shared subset.
