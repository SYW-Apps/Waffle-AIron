# Theme-builder parity and adoption blockers

Audit date: 20 October 2026. Reference: [Waffler UI at ff028e92](https://github.com/SYW-Apps/waffler-ui/tree/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c).
This is a source audit, not a live UI test. No Waffler or Registry changes are part
of this design-system work. Consumer projects own their migrations.

## The gap

Waffler's theme builder is substantially richer than the current portable theme
contract. It registers **59 theme variables**, while `theme.v1.schema.json` requires
15 palette values per mode. Those counts describe different vocabularies, not a
one-to-one mapping. In particular, custom theme v1 cannot carry Waffler's complete
authoring state, gradients, shadows, images or generated accessibility text sets.
Built-in SYW themes have a few richer presentation values; that does not give
custom themes equivalent capabilities.

**Do not replace Waffler's builder or serialize its saved themes into theme v1 as
a migration shortcut. It would discard user data and functionality.** Shared CSS
adoption can proceed incrementally while the existing builder and its storage
remain intact. Semantic tokens are not a replacement for dynamic contrast checks
on arbitrary package, entity or user-selected colors.

## Capability inventory

| Capability in current Waffler source | SYW state in 0.1.31 | Required shared behavior / preservation check |
| --- | --- | --- |
| HEX, RGB(A), HSL(A), opacity editing; RGB/HSL conversion | Portable `color.js` now provides parsing, conversion, alpha and compositing; no editor widget | Round-trip supported formats; retain alpha; do not silently turn unsupported CSS into black |
| Complement, triadic, tetradic, analogous and split-complementary colors | `getColorHarmonies`, rotation, lightness and mixing now available | Preserve the seed and all harmony roles, not only primary/secondary/accent |
| Derive a whole mode from one primary: surfaces, borders, text, focus, shadows, gradients and canvas | **Missing** shared theme derivation engine | All source roles mapped; derivation re-runs for each mode; explicit edits have documented precedence |
| Page/app/panel/strong/soft/hover/header/sidebar/menu/section surfaces | **Partial**: canvas/surface/surfaceRaised; built-in header background | Distinct generic roles and translucent layers; keep optional product-specific surfaces via typed extensions |
| Primary-strong, complement, RGB companions and harmony tokens | **Missing** runtime/custom-theme representation; color calculations alone now available | Effective overrides update RGB companions; never parse unresolved `var(...)` as HEX |
| Text/muted/subtle/inverse and generated contrast-adjusted variants for page, panel and primary | Explicit per-pair contrast resolution now available; **missing** integrated per-mode theme generation | Measure real composited backgrounds; regenerate after relevant edits/mode changes; report impossible targets |
| Base values + derived mode + explicit mode overrides + generated text variables | **Missing** authoring/override contract; v1 stores only complete mode palettes | Preserve authored vs derived values; resolve order deliberately; no silent override loss |
| Theme identity, label, description, swatches, supported/default modes, copy/delete/active selection | **Partial** identity/name/description and appearance theme reference; **missing** authoring metadata and library operations | Copy without shared mutable state; preserve identity rules and supported/default mode behavior |
| Gradients for branding/sidebar/menu/sections and a four-stop designer canvas | Built-in primary gradient only; **missing** custom-theme gradients | Typed gradient stops/interpolation and role mapping; assess text across the actual background, not one nominal stop |
| Shadow presets/manual values, shell shadow, focus ring, label shadow | Built-in surface/elevated shadows and foundation focus; **missing** custom authoring/effect contract | Structured effects and explicit consumers; preserve high-contrast behavior; do not copy unrestricted CSS into a trusted compiler |
| Canvas image upload, opacity, base/per-mode assets and fallback | **Missing** asset reference contract; Waffler retains local IndexedDB implementation | Keep portable references separate from blobs; preserve fallback, copy/delete and persistence semantics; images need actual readability checks |
| Draft list, dirty snapshots, save/reset, live previews and active-theme selection | **Missing** shared authoring workflow/demo; not provided by `installCustomTheme` | Save/reset without data loss; preview the same resolution as runtime; storage/UI stays with the host unless explicitly adopted |
| System/light/dark/high-contrast, density, text size and font preferences | Shared appearance attributes/runtime exist; storage remains application-owned | Preserve user choices, host persistence and live system-mode changes; no CSS zoom of coordinate-sensitive canvases |
| Durable themes/preferences plus legacy migration and local image assets | Portable appearance-state snapshot exists; **missing** lossless Waffler bridge | Current Waffler preference portal/wire fields and asset store retained; verify import/export round trips before replacement |

## Source paths read

- [`ThemeBuilderPanel.tsx`](https://github.com/SYW-Apps/waffler-ui/blob/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c/src/app/pages/ThemeBuilderPanel.tsx): field inventory, drafts, editing, overrides, image upload, previews and save/reset.
- [`theme/themes.ts`](https://github.com/SYW-Apps/waffler-ui/blob/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c/src/app/theme/themes.ts): 59-variable registry, harmonies, mode derivation, theme copies and RGB companions.
- [`utils/colorUtils.ts`](https://github.com/SYW-Apps/waffler-ui/blob/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c/src/app/utils/colorUtils.ts) and `utils/colors.ts`: contrast, color transforms and deterministic entity colors.
- [`App.tsx`](https://github.com/SYW-Apps/waffler-ui/blob/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c/src/app/App.tsx): effective merge order, root application, RGB companions, primary contrast, image fallback and live system preference.
- `theme/themeAssets.ts`, `theme/appearance.ts`, `theme/appearance.css`, `theme/syw-theme.ts`, `styles/themes/base.css` and `modes.css`: local assets, appearance metrics and theme consumers.
- `stores/useUISettingsStore.ts`, `stores/customThemeWire.ts`, preference portal/repository/storage adapters and appearance tests: durable preferences, wire translation and legacy migration.
- `components/common/entityAccent.tsx`: token-based accents and RGB tint companions; `components/appearance/AppearancePreferencesPanel.tsx`: preference UI.

## Preserve functionality; verify the inherited algorithms

The existing contrast helper is not itself a complete guarantee. It parses only
six-digit HEX, treats invalid input as zero luminance, chooses one search direction
from a 0.5 luminance test, and may return a color that never reached the target.
For example, gray `#808080` needs darker text at 4.5:1; white cannot reach it.
The shared resolver searches both directions, verifies serialized output and
reports unreachable targets. Unsupported CSS and missing translucent underlays
are errors rather than guessed colors. See [color tools](color.md).

Waffler's generated `eaaTextVariables` are a single stored map applied after mode
overrides. A reusable engine must track which backgrounds/mode produced a text
set and re-evaluate it after changes. A color-pair calculation must not be labeled
as full accessibility or legal compliance. The existing UI's manual previews and
CSS effects remain useful features to preserve, with their assumptions tested.

## Completion gates for the shared theme system

1. **Portable color foundation**: standalone computation, typed imports and
   verified contrast output. Implemented by this release; no CSS/React/storage dependency.
2. **Theme derivation and authoring data**: primary-driven multi-mode generation,
   all generic roles/harmonies, explicit overrides, supported/default modes,
   typed effects and product extensions. Not implemented by the color module.
3. **Lossless transport and assets**: a versioned richer authoring contract,
   references for mode/base assets, validation and explicit conversion to the
   current runtime palette. Retain original richer data; never flatten and discard it.
4. **Shared authoring example and verification**: draft/copy/edit/save/reset,
   effect/opacity editing and per-mode live previews using the actual engine;
   tests for override precedence, mode changes, text pairs and data round trips.
5. **Consumer-owned adoption**: Waffler's session evaluates a bridge against its
   existing builder, preference port, image store and coordinate-sensitive UI.
   It may retain its editor UI while using shared modules. No migration is implied
   by this audit or by publication of a new helper.

A release of step 1 is not completion of steps 2–5. Keep this table current as
capabilities are implemented and verified, and use it as an adoption gate.
