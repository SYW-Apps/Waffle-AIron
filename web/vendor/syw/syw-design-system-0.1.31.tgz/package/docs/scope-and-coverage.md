# Product scope, Waffler coverage and extraction plan

**The design system is not functionally complete against the full SYW/Waffler
scope.** A published release, functioning CDN and detailed adoption guide establish
delivery and the documented subset. They do not establish full component, form,
theme-builder or canvas parity.

This is a source audit on 20 October 2026 against
[Waffler UI ff028e92](https://github.com/SYW-Apps/waffler-ui/tree/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c).
Source and test inspection is not evidence that those tests or the live Waffler
application were executed here. Waffler remains a read-only reference in this
session; its owning session controls adoption and application changes.

## Coverage in this release

| Requested capability | Published/shared state | Work still required |
| --- | --- | --- |
| Versioned CDN/packages, docs and agent discovery | Implemented | Maintain exact-release integrity and framework-specific guidance as modules grow |
| Semantic styles, built-in themes, ordinary controls, shells and examples | Implemented subset: 29 catalogue entries and seven React wrappers | Full component inventory, specialized controls, composed templates and per-component configuration |
| Appearance preferences and dynamic contrast tools | Implemented within their documented contracts | Full generated multi-mode themes, authoring workflows, effects/assets and lossless richer theme transport; see [theme parity](theme-builder-parity.md) |
| Reusable form/layout templates | Basic field composition and example forms | Versioned composed templates with slots, data/action bindings, state coverage and editable settings |
| Generate forms from the existing Waffler JSON format | Experimental [forms core](forms-core.md): extracted condition/validation/default/value logic and pure field-list builder, checked against a pinned Waffler source snapshot | Visual form renderer, host adapters, actual producer/export fixtures, full schema editor and its reusable UI template |
| Dynamic expression pills and condition builder | Experimental [expression computation](expressions.md): source-compatible token parsing, display text, argument/condition translation and conservative conversion inspection; literal/mapped transitions and condition evaluation in forms core | Experimental [headless editing](input-editing.md) now supplies source selections, atomic operations, nested condition edits and typed host contracts; actual DOM/caret/composition transport, undo/redo, visual pill/condition editor UI, host implementations and skins remain |
| Themed overlays and notifications | Experimental tooltip/menu/popover surface skins, native dialog styling and optional [React Toastify adapter](overlays.md); adoption acceptance policy | Complete tooltip/menu positioning and interaction adapters; consumer-owned portal, keyboard and announcement verification |
| Rich field concepts | Ordinary input/select/textarea presentation only | Primitive, structured, date/time, code/Markdown, dynamic/reference and provider-backed field renderers |
| React Flow canvas styling and common configuration | No canvas adapter or canvas styling profile | Reusable canvas roles/settings and an adapter with caller-supplied nodes, edges, callbacks and stores |
| Equivalent visual concepts in other canvas engines/frameworks | No portable canvas profile contract or adapter matrix | Renderer-neutral roles/configuration plus explicit engine bindings and declared capabilities |
| Multiple reusable component/canvas profiles, extensions and contributed variants | No versioned style-profile library | Named profiles, inheritance/overrides, local scope, preview/catalogue entries and contribution review |

`--syw-color-canvas` currently means the page background, not a complete graph
canvas contract. `syw-chip` is a static chip presentation, not an expression editor.
An example form is not a JSON form generator. The React adapter's native form
markup is not coverage of Waffler's specialized field behavior.

## Independent modules and styling

The design-system product can distribute reusable behavior as companion modules.
The core CSS package must not acquire mandatory form, React Flow, editor, Waffler
service or React dependencies. Names below describe boundaries, not existing
package exports or committed final package names.

| Boundary | Owns | Can be used without |
| --- | --- | --- |
| Visual foundations and theme engine | Semantic roles, appearance settings, color calculations, theme generation, visual profiles and effects | Form or canvas engines |
| Form contracts/runtime | Schema/value normalization, defaults, recursive structure, conditions, validation and renderer/provider interfaces | SYW styling, React, canvas state or a Waffler connection |
| Input concepts/controllers | Expression tokens, pill editing semantics, condition structures and translation | One particular theme or application registry |
| Form renderer and builder adapters | Rendering/editing schemas in a supported framework; controlled values, events and slots | SYW skin or the Waffler application shell |
| SYW component skin and templates | Styled field/pill/condition/wizard surfaces, layouts, component states and composed examples | JSON generation; hand-written forms can use the same controls |
| Canvas contracts/profiles | Canvas visual roles and typed, portable configuration; declared renderer capabilities | A fixed node catalogue or a Waffler execution model |
| Engine-specific canvas adapters | Apply profiles and map supported configuration to an engine such as React Flow | Waffler nodes, registry, graph store or execution services |

The same form schema and values must work with the SYW renderer skin, an alternate
skin, or a consumer-owned renderer without changing the data contract. Preserve
field concepts and interaction semantics while changing presentation. For
example, dynamic inputs retain expression pills and Boolean conditions retain
their structured editor; replacing them with ordinary text boxes loses behavior.

Framework neutrality applies to contracts/data and portable computation. A React
form renderer is still a React adapter, and React Flow is still a React engine.
Other renderers require their own explicit implementation and verification.

## Component settings and composed templates

Inventory configuration for each component family, not only page-level colors:
surfaces/borders/radii/elevation, typography/spacing/density, icons/adornments,
orientation/layout and applicable hover/focus/selected/disabled/read-only/invalid/
loading states. Publish typed settings and semantic token bindings with supported
variants and scope. Behavior remains in the control/controller; presentation
settings must not remove labels, keyboard semantics or validation messages.

Templates need versioned composition, named slots, required inputs, responsive
rules, allowed overrides, accessibility/appearance evidence and binding examples.
Include composed form sections, settings pages, wizards and other reusable layouts,
with plain markup and framework examples where implemented. A template may use a
schema-driven form or hand-written controls; the form runtime is an optional
dependency of the composition, not the styling system's only entry point.
Business actions and persistence are supplied by the consuming application.

## Waffler form extraction requirements

The current source contains both the React schema builder/runtime under
`src/app/schema/` and a newer pure field-list `FormBuilder` in
`src/schema/form-builder.ts`. These are different capabilities. Extracting only
the latter would not deliver the dynamic form renderer or authoring UI.

Preserve the existing JSON contract deliberately:

- `FormField` uses `key`, `label`, `type`, `ui`, `constraints` and
  `default_value`; `WafflerSchema` holds `fields` and optional `wizards`.
- `InputValue` keeps `value` and `metadata`, including `mapped`, type hints,
  source and the Boolean condition-builder sub-mode. Do not flatten it to raw
  strings or lose metadata when changing input modes.
- Keep canonical field kinds, reference/entity resolution, explicit legacy-kind
  normalization, nested objects/arrays, generics and application extensions.
  Validate compatibility against the authoritative producer/wire fixtures before
  claiming a shared implementation accepts Waffler JSON.
- Keep defaults without overwriting authored values; ordered grouping, conditional
  visibility, read-only/required/mappable state, local/external errors, dynamic
  options and wizard results need their own preservation cases.
- Retain semantic UI hints such as renderer choice, descriptions, multiline mode,
  groups and bounds. Move colors, typography, borders and effects to skins/profiles;
  preserve/translate existing layout hints explicitly rather than discarding them.
- Map variable/function suggestions, reference/type resolution, option loading,
  actions, secret/connection/entity pickers, draft state and overlay placement to
  injected host interfaces. The generic runtime must work with in-memory providers
  and must not require Waffler's stores, RPC client, vault or designer providers.
- Expression parsing/editing and evaluation are separate capabilities. Preserve
  Waffler expression syntax through a language adapter and round-trip fixtures;
  a form schema must not implicitly execute arbitrary expressions or commands.

Field coverage must include ordinary text/number/Boolean/select and variants,
date/time/duration, arrays/objects, code/Markdown/color, dynamic/reference fields,
condition editing, expression pills and provider-backed picker concepts. Optional
editors and provider integrations should remain separately loadable. Waffler's
domain operations are host implementations, not part of the generic skin.

For pills, carry forward literal/token interleaving, variables and function
reference/invocation, raw-expression fidelity, selection/copy/paste, caret and
keyboard behavior, multiline input, read-only/disabled state and overlay anchoring.
For conditions, carry forward nested AND/OR, supported operators, value semantics,
expression/structure round trips and an explicit outcome for expressions the
builder cannot represent. A parser failure must not erase the original expression.

## Canvas profiles and caller-owned graph elements

Extract visual/interaction concepts from the canvas rather than copying Waffler's
entire `CanvasLayer` into shared core. It currently imports blueprint and designer
stores, registers Waffler nodes, switches to playback edges, and adds a playback
overlay. Those are application dependencies.

A reusable adapter accepts caller-supplied node/edge registries, graph data,
callbacks, overlays and state. A generic visual node-frame or connector primitive
may be offered separately; it must not select the app's node types or impose its
execution semantics.

Canvas appearance includes solid/gradient/image backgrounds, grids/dots/lines,
grid spacing/size/opacity, generic node/edge/handle/selection roles, minimap,
controls, focus/read-only/disabled states, and restrained/reduced motion. The
profile maps these semantic roles to supported engine styling; arbitrary Waffler
category colors and playback meanings remain caller-provided role mappings.

General configuration includes pan/zoom limits, snapping, selection, minimap and
controls visibility, read-only policy, keyboard bindings and movement-related
performance settings. Keep this configuration distinct from pure visual styling
and from graph contents. Adapters must report unsupported settings and preserve
host event ownership rather than silently dropping settings or overriding keys.

Use engine coordinates for viewport zoom. Text-size/density choices, overlays,
pointer transforms and page scrolling need explicit integration tests; global
CSS zoom and global `body { overflow: hidden }` are not acceptable shortcuts.

## Reusable profiles and contribution model

A theme supplies semantic appearance across an application. A style profile is a
reusable selection of component/canvas presentation and optional separately typed
interaction defaults. A template composes elements and slots; a form schema
describes fields/data/behavior. These should be independently selectable.

Current `appearance-profile.v1.schema.json` stores preferences and per-app
overrides. Catalogue `supportProfiles` describe the tested appearance matrix.
Neither is the proposed selectable, versioned component/canvas profile library.

The new profile contract needs identity/version, scope, typed roles/settings,
exact parent references where extended, declared adapter capabilities, support
matrix and provenance. Specify override precedence and validation explicitly.
Application overrides stay local; two canvases on the same page may choose
different profiles. Styling changes must retain input semantics, focus and
contrast behavior. A profile does not certify arbitrary user colors/images.

An app may choose a shared profile, derive another one and continue independently.
When useful, its owner can propose that variant upstream. Review it with examples,
round-trip data and visual/interaction evidence, then publish it as another named
experimental/stable option. Adoption remains opt-in; existing pins do not change
when a profile is contributed. Reviewable evidence of reuse is sufficient to
consider an initial profile; it need not wait for a second app to implement a copy.

## Delivery sequence and completion gates

1. **Inventory and fixtures** — maintain this matrix and map requested Waffler
   concepts to shared, host-adapted or product-owned behavior. Capture representative
   wire/schema/value/condition/template and canvas fixtures before extraction.
2. **Theme/profile contracts** — expand [theme-builder parity](theme-builder-parity.md)
   into a richer authoring engine and versioned component/canvas profile contract,
   with explicit scope/override rules and mode-aware contrast validation.
3. **Form behavior and input concepts** — extract portable schema/value/condition
   computation and compatibility fixtures, then renderer-neutral provider/controller
   interfaces. Retain existing syntax/data and identify unsupported cases visibly.
4. **Form renderers, templates and authoring UI** — ship a React adapter plus SYW
   skin and alternate/unstyled example; carry forward pill/condition interactions,
   all agreed field families, wizards and schema editing. Keep heavy integrations
   optional and hand-written forms able to use controls without the generator.
5. **Canvas profiles and React Flow adapter** — ship at least two independently
   selectable scoped visual profiles, explicit configuration/capability mapping,
   consumer-defined graph elements, and coordinate/interaction tests. Document the
   contract for other engines without claiming unimplemented adapters exist.
6. **Catalogue and owner-led adoption** — publish real templates/profile demos,
   configuration references, installable modules, framework routes and migration
   fixtures. Consumer owners review their bridges; this session develops shared
   modules and does not initiate changes to unrelated applications.

Each shipped capability needs a documented public contract, an independently
usable artifact, relevant functional/accessibility/appearance evidence, and
preservation tests against the reference cases. An inventory, schema, package
name or demo alone does not satisfy its gate. These gates track known requested
coverage; extensibility and additional reviewed profiles cover future cases
without promising an implementation for every possible application or renderer.

## Source references

All Waffler links below identify the audit snapshot, not a claim of live parity:

- [Unified form contracts](https://github.com/SYW-Apps/waffler-ui/blob/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c/src/app/schema/common/types.ts), [value metadata](https://github.com/SYW-Apps/waffler-ui/blob/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c/src/app/types/expressions.ts), and [pure field-list builder](https://github.com/SYW-Apps/waffler-ui/blob/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c/src/schema/form-builder.ts).
- [DynamicForm](https://github.com/SYW-Apps/waffler-ui/blob/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c/src/app/schema/runtime/DynamicForm.tsx), [FieldRenderer](https://github.com/SYW-Apps/waffler-ui/blob/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c/src/app/schema/runtime/components/FieldRenderer.tsx), [validation](https://github.com/SYW-Apps/waffler-ui/blob/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c/src/app/schema/runtime/validation.ts), and [schema editor](https://github.com/SYW-Apps/waffler-ui/blob/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c/src/app/schema/builder/FormBuilder.tsx).
- [AlwaysPillInput](https://github.com/SYW-Apps/waffler-ui/blob/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c/src/app/schema/runtime/components/AlwaysPillInput.tsx), [token parser](https://github.com/SYW-Apps/waffler-ui/blob/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c/src/app/schema/runtime/components/tokenParser.ts), [condition editor](https://github.com/SYW-Apps/waffler-ui/blob/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c/src/app/schema/builder/components/ConditionBuilder.tsx), and [condition translation](https://github.com/SYW-Apps/waffler-ui/blob/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c/src/app/schema/builder/conditionTranslator.ts).
- [CanvasLayer](https://github.com/SYW-Apps/waffler-ui/blob/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c/src/app/designer/layers/CanvasLayer.tsx), [interaction/node CSS](https://github.com/SYW-Apps/waffler-ui/blob/ff028e92d945b64de7ea98dea2bd66c7c3beaf6c/src/app/styles/index.css), and the [theme audit](theme-builder-parity.md).
- Existing tests reviewed include `DynamicForm.test.tsx`, `FieldRenderer.test.tsx`
  and `AlwaysPillInput.test.tsx` beside those components. They are reference cases
  to carry forward, not a substitute for testing extracted standalone modules.
