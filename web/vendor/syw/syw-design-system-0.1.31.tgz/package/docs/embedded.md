# Embedded, Shadow DOM and Authentik integrations

Read [implementation](implementation.md), then establish which application owns
the document, attributes, reset, persistence and authentication. Embedded styling
must not change the host's global layout or native theme contract.

## Shadow DOM

Use component CSS inside the shadow root. Supply inherited foundation metrics
and semantic theme tokens, plus scoped focus-visible, density, text-size/font
and reduced-motion behavior. Importing `components.css` alone does not create
those tokens or the interaction logic. Keep styles available locally when the
host requires offline/bundled behavior.

Native shadow roots and forced ShadyDOM compatibility mode are different paths.
For ShadyDOM/ShadyCSS hosts, put bundled CSS in template style elements, call the
host's existing `ShadyCSS.prepareTemplate` before stamping the template, then
`styleElement`/`styleSubtree` after rendering as required by that host. External
stylesheet links inside a shadow root do not provide equivalent shimmed styles.
Do not inject another incompatible Web Components polyfill into the host.

Give every instance unique label/tab/panel IDs. Preserve disabled behavior,
keyboard navigation, hidden inactive panels, modal focus and focus return. Test
both the native and forced compatibility path when the application supports both.
A working authenticated page does not establish that the anonymous login page
uses the same CSS/polyfill path.

## Namespaced appearance

The optional runtime supports a root and prefix for appearance attributes:

```js
import { setAppearance } from 'https://cdn.sywapps.com/ui/0.1.31/runtime.js';
setAppearance({ theme:'waffler', mode:'dark', density:'compact' },
  { root:document.documentElement, prefix:'syw' });
```

That writes namespaced state such as `data-syw-theme`; the corresponding token/
attribute bridge is still required. Do not set a host's native `data-theme` to a
SYW theme ID when that host uses it for its own light/dark behavior.

## Authentik

Use the existing `integrations/authentik/bridge.css`, `skin.css` and standalone
integration assets according to the owning overlay's documentation. Keep native
`data-theme` and account/session/authentication logic upstream. The active overlay
already implements native and forced-compatibility styling and regression tests;
its session owns upgrades. Do not reinterpret a general guide as permission to
rewrite authentication, change Brand CSS or redeploy the service.

## Other embedded hosts

Keep resets and fixed-viewport shells out of the host document. Prefer an owned
root/iframe or scoped component integration; verify portals, menus, focus and
scrolling at the actual embedding boundary. Report unsupported style scoping
upstream instead of removing host functionality to fit a generic example.
