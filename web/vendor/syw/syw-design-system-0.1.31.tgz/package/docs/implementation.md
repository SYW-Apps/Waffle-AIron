# Implementing the SYW Design System

This is the generic implementation guide for **0.1.31**. It is public,
versioned with the code, and intended for both developers and agents. Start here,
then read the platform page and linked contracts that apply to your application.
The application’s own session owns its migration, checks and deployment.

Read [product scope and current coverage](scope-and-coverage.md) before choosing
what to replace. This release does not provide Waffler's JSON form generator,
schema builder, expression-pill/condition editors, reusable canvas adapter or
selectable style-profile library. Retain those existing capabilities and adopt
only the shared surface that has a verified equivalent. The linked plan separates
form behavior from styling and canvas profiles from application graph elements.

The experimental [forms core](forms-core.md) now extracts computation and pure
field-list editing against a pinned Waffler snapshot. It is independently usable
without styling, but does not replace the visual form renderer or builder UI.

## One prompt for the owning application session

> Read https://cdn.sywapps.com/ui/v0/docs/implementation.md and its linked guide
> for this project's framework. Resolve one exact published release and use its
> docs, manifest and catalogue together. Audit current adoption and theme ownership,
> then adopt the design system for the requested application scope. Preserve
> behavior, routing, authentication, appearance choices, dynamic contrast checks
> and richer custom-theme data. Preserve schema-driven forms, expression/condition
> controls and canvas behavior until a verified shared equivalent exists. Use the
> existing toolchain and CI. Verify the
> actual flow and report unsupported shared requirements to the design-system
> session. Return a focused PR through this project's normal review process.

Replace “requested application scope” with a named page/flow when possible. A
request to read the guide or assess adoption does not itself authorize unrelated
repository, infrastructure or deployment changes.

## Choose a route

| Application | Read next | What is shared |
| --- | --- | --- |
| Static HTML, server-rendered templates, Jinja | [HTML guide](html.md) | CSS, semantic HTML and optional ESM helpers |
| React 18/19 | [React guide](react.md) | Same CSS plus the thin React adapter |
| React with existing MUI | [MUI guide](mui.md) | CSS-variable mappings; preserve the existing provider |
| Vue, Svelte, Angular or another DOM framework | [Other frameworks](frameworks.md) | CSS/DOM contract and framework-neutral helpers |
| Tauri, Electron, offline/PWA client | [Offline/desktop guide](offline.md) | Assets compiled into the application; no live CDN required to render |
| Embedded/Shadow DOM/Authentik overlay | [Embedded guide](embedded.md) | Scoped components and inherited tokens without host resets |
| Native UI without a browser renderer | [Other platforms](frameworks.md#native-platforms) | Token data/build-time output; no native widget adapter is currently supplied |

All routes should read [components](components.md), [color and contrast](color.md),
[appearance storage](appearance-storage.md), and [theme-builder gaps](theme-builder-parity.md).

## 1. Inspect the application before changing it

Read repository instructions and the current package/lockfile, entry point,
providers, root styles, router, authentication boundaries, theme builder,
preference persistence, service worker and normal check/deployment scripts.
Identify current design-system imports and their versions; legacy
`https://cdn.sywapps.com/css/syw.css` is not the immutable release contract.

Inventory the requested flow's buttons, fields, cards, navigation, dialogs,
loading/empty/error states and interactions. Record which are generic primitives
and which express product behavior. Keep network calls, authorization, domain
validation, media/canvas behavior, layout composition and product state local.

## 2. Resolve and pin one published release

For a new adoption, read the [major-channel manifest](https://cdn.sywapps.com/ui/v0/manifest.json),
record its version, then fetch the **exact** release's manifest, documentation,
[tarball index](../packages/tarballs/index.json) and [catalogue](../catalogue.json).
For an existing consumer, inspect its pin first; make an upgrade intentional.
This guide's exact release manifest is [0.1.31](../manifest.json).

Verify that manifest/package versions agree and verify downloaded artifacts
against the manifest hashes. Do not mix floating-channel CSS with exact-version
adapters or helper scripts. A successful source build is not publication evidence.

Decide delivery explicitly:

- Exact CDN tarball dependencies are downloaded during package installation; the
  lockfile pins integrity. A cold install still needs the CDN or a cache/mirror.
- Importing installed CSS/JS lets the app's bundler emit local application assets.
  Verify the output and runtime requests before claiming offline rendering.
- Verified local tarballs or an approved internal mirror support disconnected
  builds. Keep those files and lockfile according to the project's policy.
- Direct CDN stylesheet/module links need the CDN at runtime. Use exact URLs and
  an appropriate CSP. Do not use live fallback for an offline desktop shell.

See [distribution](distribution.md) for commands and the full distinction.

## 3. Load styles once, in the correct order

The aggregate `syw.css` includes foundation, base, components, shells, recipes and
the default SYW Apps theme. For another built-in theme, also load its theme file.
Alternatively import the required layers explicitly: `core.css`, `components.css`,
optional `shells.css`/`recipes.css`, then the selected theme, then app extensions.
Choose one route so resets and component rules are not duplicated.

For a document you own, set `data-theme` and `data-mode` on `html`. Select a theme
whose CSS is actually loaded. Follow the embedded guide when the host owns those
attributes or styling. Shared foundation does not force a fixed viewport or hide
body scrolling. Opt into a shell only if it matches the application layout.

Keep local extension rules after shared CSS, scoped to product classes. Retire
old `.btn`, field or utility rules gradually. Exclude migrated shared classes
from broad legacy rules so they do not override focus, height, padding or colors.

## 4. Use the real component contract

Use the exact release's [live catalogue](../examples/catalogue/index.html) and
machine-readable [catalogue.json](../catalogue.json). Each item records its
classes, tokens, example HTML/JS/React, support profile and accessibility duties.
CSS implements presentation; it does not create event handling or application
semantics. Plain-HTML interactive examples need their JavaScript as well.

[The component guide](components.md) maps wrappers to native markup and describes
forms, tabs, segmented controls, dialogs and states. Do not invent APIs such as
`SywProvider`, `SywInput`, `SywSelect` or `SywDialog`; they are not current exports.
Keep persistent labels, relationships, visible focus, native disabled behavior
and explicit invalid/error presentation. Preserve existing validation timing.

## 5. Preserve appearance and theme authoring

Keep the existing user preference store; use [appearance runtime/state contracts](appearance-storage.md)
as adapters to that store. Theme/mode, density, text size, font and motion are
independent choices. Do not implement CSS zoom for coordinate-sensitive editors.
The runtime applies state; it does not provide account synchronization or a
storage backend. Scope host integration through documented prefixes when needed.

The current portable custom palette is **not** a lossless representation of the
Waffler theme builder. It cannot carry all generated harmonies, mode overrides,
effects, assets and draft/library state. Preserve the richer data and existing
builder. The [parity audit](theme-builder-parity.md) lists exact adoption blockers;
[theme architecture](themes.md) describes current validation and limitations.

The [expression module](expressions.md) provides independent Waffler-compatible
parsing, argument serialization and condition translation. Preserve the original
expression and auxiliary metadata; consult its conversion limits and conservative
inspection before placing an existing expression into a structured editor.
The [input editing module](input-editing.md) adds framework-neutral pill and condition
operations with source and metadata preservation. Neither module supplies expression
execution or the visual pill/condition UI.

## 6. Keep dynamic color and contrast functionality

Semantic text tokens cover defined theme roles; they do not resolve arbitrary
package, entity, user or uploaded-image colors. Preserve existing contrast logic
until a replacement is verified against the actual rendered background.

Use the standalone [color module](color.md) from `@syw/design-system/color` or the
exact `color.js` URL. It measures/adjusts sRGB pairs, handles alpha with an explicit
underlay, supplies harmonies/transforms and reports unreachable targets. Pass the
real surface, inspect results, and recompute after relevant color, mode or opacity
changes. Never substitute an obsolete hardcoded dark surface for the current UI.
A solid-pair result does not certify a gradient/image or the entire application.

## 7. Verify the actual adopted flow

Run the project's existing build, type/lint checks and relevant tests. Verify:

- Keyboard/pointer behavior, accessible names, focus visibility and focus return.
- Enabled, selected, disabled, invalid/read-only, loading, empty and failure states
  that exist in the flow; failure recovery must not leave stale errors/results.
- Applicable themes and light/dark/high-contrast, cozy/compact, larger text and
  reduced motion; measure actual text/action/background contrast.
- Narrow and desktop layouts, native page scrolling and overflow behavior.
- URL/history, auth/API, persistence and product-specific behavior retained.
- Bundled CSS/helpers and service-worker caches when offline rendering is claimed;
  offline styling does not imply offline APIs or authentication.

Use meaningful existing checks and focused additions. Adoption does not require a
new CI/deployment system. Report gaps upstream instead of silently dropping
features or creating another generic control library.

## 8. Report and review

Return the exact release, changed surfaces, preserved behavior, checks/evidence,
remaining local styles and known unsupported capabilities. Distinguish source,
CI, publication, deployment and live verification. Follow the owning project's
normal review and rollout. Other applications do not upgrade automatically when
a new design-system guide or helper is published.

## Overlay adoption requirement

Tooltips, context menus, dialogs/modals and toasts are required adoption surfaces,
including portal roots. Use [themed overlays](overlays.md), preserve keyboard/focus
and announcement behavior, and include actual rendered evidence. Use styled app
dialogs for prompts; do not leave browser alert/confirm/prompt calls or unstyled
vendor overlays. An optional React Toastify module is available; core remains
independent of it. Consumer owners control their own lint/CI enforcement.
