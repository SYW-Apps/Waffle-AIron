# Desktop, PWA and offline rendering

For Tauri, Electron or an offline-capable web client, compile exact design-system
CSS and helpers into the application. Read [distribution](distribution.md) for
install-time CDN dependencies and verified local tarball/mirror options, and use
the [React](react.md) or [HTML](html.md) route matching the renderer.

## Build boundary

Import installed `core.css`, `components.css` and the selected theme (plus optional
shell/recipe layers) from the existing client entry point. Import color helpers
from `@syw/design-system/color`; import the optional browser appearance runtime
from `@syw/design-system/runtime`. The color module also runs in workers/Node;
the appearance runtime requires a document and is not an SSR/native-UI module.

Inspect emitted files and network requests. There should be no runtime CDN CSS/JS
request required for startup. Do not implement “remote stylesheet when online,
local fallback when offline” as two independent styling sources. Keep the local
application's CSP, protocol handling, asset loader and package updater intact.

## PWA service workers

Add emitted structural CSS/JS to the existing static precache policy if it is not
already included by the bundler/PWA tooling. Use the app's normal cache lifecycle.
Do not cache authentication/configuration or API data as a side effect of adopting
styles. Offline rendering means the shell retains its layout and appearance;
it does not promise that package searches, authentication or other APIs work offline.

Verify a production build under the actual service worker: load once, wait for
activation/control, disable the network and reload. Check that CSS/helpers are
served from bundled/precache assets and that the application's offline/error
behavior remains accurate. Dev-server rendering alone is not that verification.

## Preferences and rich themes

Start from bundled defaults and the existing local preference store. Optional
synced appearance data must be validated and cached deliberately; publication of
new shared CSS does not authorize changing an offline client's installed version.
Keep richer theme-builder data and local image assets; theme v1 is a smaller
palette contract, not a lossless backup. Preserve canvas coordinate behavior,
keyboard shortcuts, designer performance and intentional window scrolling.
