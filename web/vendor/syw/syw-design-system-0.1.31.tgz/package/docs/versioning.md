# Versioning and CDN channels

SYW Design System uses semantic versioning for its **public contract**.

## Release meaning

- **PATCH** — bug fixes, accessibility fixes, small visual tuning, implementation corrections; no removed/renamed public contract.
- **MINOR** — additive tokens/components/patterns and compatible visual evolution; existing public contract remains valid.
- **MAJOR** — removals, renames or behavioral changes requiring consumer work.

Visual output can evolve within a major version. Consumers needing pixel-frozen output should pin an exact release.

## CDN forms

A release publisher should expose all three:

```text
/ui/1.3.2/syw.css          # immutable exact release
/ui/v1/syw.css             # floating major channel -> latest compatible 1.x
/ui/latest/syw.css         # newest release across majors; preview/docs only
```

The same applies to individual files such as `core.css`, `components.css`, `runtime.js`, token JSON and themes.

### Recommended consumer policy

- Critical/stable applications: exact version.
- First-party applications that should receive improvements automatically: floating major (`v1`).
- Design catalogue/examples: `latest`.

Never silently move `v1` to v2.

## Integrity

Exact release manifests should contain SHA-256/SRI hashes. Floating aliases cannot use a fixed SRI value because their content intentionally changes.

## Deprecation

Deprecate in a minor release, document migration, and remove no earlier than the next major release.
