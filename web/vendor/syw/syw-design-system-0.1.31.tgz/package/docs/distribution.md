# Distribution and offline applications

The design system is a source contract with multiple distribution targets. CDN delivery is not the canonical runtime requirement.

## Web applications

First-party online web applications may consume either an exact immutable release or a floating compatible-major CDN channel:

- `/ui/1.4.2/syw.css` — exact immutable release.
- `/ui/v1/syw.css` — latest compatible v1 release.
- `/ui/latest/syw.css` — development/catalogue use only.

## Package-ready release output

Every design-system build is also a package root. `dist/package.json` exposes the same immutable release artifacts through explicit subpaths rather than creating a second package-specific build tree.

Core examples:

```ts
import '@syw/design-system/core.css';
import '@syw/design-system/components.css';
import '@syw/design-system/shells.css';
import '@syw/design-system/themes/syw-apps.css';
import {
  applyAppearanceState,
  installCustomTheme,
  setAppearance,
} from '@syw/design-system/runtime';
```

The package also exposes the portable data contracts directly, including `tokens.json`, `catalogue.json`, `themes/builtins.json`, and the versioned schema JSON files.

The release package includes TypeScript declarations for the framework-neutral runtime and independent [color/contrast module](color.md). The latter is also served as standalone `color.js` with no runtime dependencies. React and MUI adapters remain separate package boundaries so the core package does not acquire framework peer dependencies.

## Installable immutable tarballs

Every immutable CDN release also carries normal npm-compatible tarballs for all package roots:

```text
/ui/<version>/packages/tarballs/
  index.json
  syw-design-system-<version>.tgz
  syw-design-react-<version>.tgz
  syw-design-mui-<version>.tgz
```

`index.json` is the canonical filename lookup and records the three tarball names for that exact release. The tarballs themselves are hashed in the normal release `manifest.json`, so they inherit the same immutable transactional publication guarantees as CSS, runtime and schemas.

This allows a first-party application to install an exact release without waiting for registry publication. For example, a pnpm dependency may point at an immutable HTTPS tarball URL:

```json
{
  "dependencies": {
    "@syw/design-system": "https://cdn.sywapps.com/ui/0.1.14/packages/tarballs/syw-design-system-0.1.14.tgz"
  }
}
```

### Install time, build time and runtime are different

An HTTPS tarball dependency is downloaded by npm/pnpm during installation or
update. It is not a local vendored file. The lockfile's integrity verifies its
content; it does not remove the need to reach the CDN on a cold install.

Once application source imports the installed CSS/JS, a bundler such as Vite can
emit it into same-origin application assets. Verify those emitted assets and
runtime requests before claiming that the app bundles its design system. A
runtime `<link>` or ESM import pointing at the CDN still depends on that service.

For disconnected/reproducible installs without external CDN availability, a
consumer may download the exact tarballs once, verify their SHA-256 against the
release manifest, and commit them under an approved vendor directory or mirror
them internally. For example, after verified files exist locally:

```sh
npm install --save-exact ./vendor/syw-design-system-0.1.31.tgz ./vendor/syw-design-react-0.1.31.tgz
```

Commit those files and the updated lockfile according to the consumer's policy.
The consumer chooses this delivery route and uses its existing CI; adopting the
design system does not require new deployment infrastructure.

Use exact-version URLs for application dependencies. Do not install packages through `v0` or `latest`: lockfiles should resolve to an immutable artifact.

The repository does not currently publish automatically to a package registry. Connecting npm/GitHub Packages remains a separate distribution-policy and credential step; the CDN tarballs provide the deterministic package transport in the meantime.

## Tauri and offline-capable applications

Tauri applications must bundle the structural design system into the application build. They must not require a public URI to render correctly.

A React/Tauri build should import the package artifacts during compilation:

```ts
import '@syw/design-system/core.css';
import '@syw/design-system/components.css';
import '@syw/design-system/themes/syw-apps.css';
import { applyAppearanceState } from '@syw/design-system/runtime';
```

Vite/Tauri then emits those assets into the application bundle. The exact installed design-system version becomes part of the app build and remains reproducible offline. Network access is needed only when dependencies are installed or updated, not when the built application starts or renders.

## Optional cached theme synchronization

Remote synchronization, when desired, should be limited to data-oriented appearance packs rather than replacing core component CSS at runtime.

Recommended split:

- **Bundled:** foundation, components, shells, layout contracts, runtime behavior and a default theme.
- **Optionally synced/cached:** compatible theme-token packs, brand assets or user-created themes with a declared schema/version.

The application always starts from bundled defaults. If a previously validated compatible theme pack exists in local app data it may be applied offline. When online, the app may check for a newer compatible theme pack, validate it, store it locally and use it on a subsequent render/restart.

Remote packs must declare the core contract/major version they require and must be validated against a whitelist of supported semantic tokens. Arbitrary remote CSS is not the preferred extension mechanism.

## Why not live CDN fallback for desktop?

A `remote CSS when online, bundled CSS when offline` strategy creates two runtime sources of truth and makes the exact rendered application depend on network/cache state. It also complicates CSP, debugging and release reproduction. For desktop software, structural styling should therefore update through an intentional app/design-system dependency update rather than through a live stylesheet URL.
