# Portable color and contrast tools

`color.js` is an independent ESM file with no imports, DOM access, framework,
stylesheet, storage or network behavior. It runs in browsers, module workers,
Node and bundled clients. This module supplies color computation; it does not
replace the [full theme builder](theme-builder-parity.md).

## Import

Direct browser use, after this exact release is published:

```html
<script type="module">
  import { findClosestAccessibleColor, getContrastRatio }
    from 'https://cdn.sywapps.com/ui/0.1.31/color.js';
  const background = '#0d1b2a';
  const foreground = findClosestAccessibleColor('#8b5cf6', background, 4.5);
  console.log(foreground, getContrastRatio(foreground, background));
</script>
```

From the exact installed core package, including TypeScript declarations:

```ts
import {
  findClosestAccessibleColor, resolveAccessibleColor, resolveTextColors,
  getContrastRatio, getColorHarmonies,
} from '@syw/design-system/color';
```

`@syw/design-system/color.js` is an equivalent subpath. No React adapter or CSS
import is required. See [distribution](distribution.md) for install-time CDN
fetching, runtime bundling and local vendoring. A module imported directly from
the CDN has a runtime network dependency; a bundled/vendored module does not.
The release manifest hashes `color.js` and `color.d.ts` along with the tarballs.

## Contrast behavior

```js
const result = resolveAccessibleColor('#888888', '#808080', 4.5);
// { color, ratio, targetRatio, meetsTarget, adjusted, reason }
// reason: 'already-passes' | 'adjusted' | 'unreachable'
if (result.meetsTarget) label.style.color = result.color;
```

The default target is 4.5. `findClosestAccessibleColor(fg, bg, target)` returns a
color only when that target is met; otherwise it throws `RangeError`. Use the
result API when the application needs to offer a fallback. Neither API guesses
the background. Existing applications must pass their actual surface, rather
than retaining an old hardcoded dark-theme default after changing the surface.

Passing foregrounds remain unchanged. The resolver preserves hue, saturation and
alpha and searches both directions of HSL lightness. It selects the smaller
lightness change along those two paths, verifying the final serialized color.
"Closest" refers to this HSL search, not a globally minimal perceptual difference.
The reported ratio is unrounded for threshold comparisons. Targets must be finite
numbers from 1 to 21. An unreachable result supplies the best black/white endpoint
at the original opacity and `meetsTarget: false`; it never claims success.

Alpha is preserved and measured by source-over compositing in encoded sRGB:

```js
getContrastRatio('rgba(0, 0, 0, .7)', '#ffffff');
getContrastRatio('#111111', 'rgba(255, 255, 255, .8)', { underlay: '#222222' });
resolveAccessibleColor('rgba(100, 100, 100, .8)', '#ffffff', 4.5);
```

A translucent background requires an explicit opaque `underlay`. For deeper
layers, compose them with `compositeColors(foreground, background)` first.
Zero/low foreground opacity may make a target impossible even at black or white.
Unsupported/invalid colors throw; no invalid-input-to-black fallback is applied.

## Color and palette operations

| Export | Contract |
| --- | --- |
| `parseColor(value)` | `{r,g,b,a}`; HEX 3/4/6/8 digits (optional `#`), RGB(A), HSL(A), `transparent`; comma or modern space/slash syntax |
| `toHex(value)` | 8-bit HEX for opaque input; rejects alpha instead of dropping it |
| `rgbToHsl(r,g,b)` / `hslToRgb(h,s,l)` | RGB channels 0..255; hue in degrees, saturation/lightness 0..1 |
| `getLuminance(value)` | WCAG sRGB relative luminance of an opaque color |
| `getContrastRatio(fg,bg,options?)` | Measures actual composited pair; alpha background needs `underlay` |
| `rotateHue(value,degrees)` | Hue rotation, preserving saturation/lightness/alpha |
| `adjustLightness(value,delta)` | Additive HSL lightness adjustment, delta -1..1, clamped |
| `mixColors(first,second,weight=.5)` | Weight belongs to first; premultiplied encoded-sRGB interpolation; opaque behavior matches Waffler's mix convention |
| `withAlpha(value,alpha)` | Replaces opacity, alpha 0..1 |
| `compositeColors(fg,bg)` | Source-over result; may remain translucent until placed on an opaque layer |
| `getColorHarmonies(primary)` | Primary, complement, triadic, tetradic, analogous and split-complementary colors |
| `resolveTextColors(pairs,target=4.5)` | Named explicit pairs, resolved colors and per-pair results, aggregate `meetsTarget` |

Harmony arrays include the primary: triadic `[0,120,240]`, tetradic
`[0,90,180,270]`, analogous `[-30,0,30]`, split-complementary `[0,150,210]`.
Palette transforms emit 8-bit channels; conversions and measurement retain
fractional channels. Mixing is not perceptual/linear-light color interpolation.

Use named pairs to keep contexts separate:

```js
const text = resolveTextColors({
  page: { foreground: '#777777', background: '#f7f8ff' },
  panel: { foreground: '#777777', background: '#ffffff' },
  primary: { foreground: '#ffffff', background: '#22ddff' },
});
// Inspect text.meetsTarget and text.results before applying text.colors.
```

## Application responsibilities and limits

Read the actual rendered color/background at the component being styled. Browser
computed colors in RGB form are supported. Recompute after mode, surface, color
or opacity changes; the module deliberately has no document observer or storage.
Unresolved `var(...)`, `currentColor`, named colors other than `transparent`,
gradients, images, wide-gamut colors and CSS math are not parsed. Resolve these
in the host or supply known sRGB pairs. A single solid pair does not establish
contrast across a gradient/image or text with ancestor opacity/blending.

The formula follows [WCAG sRGB relative luminance](https://www.w3.org/WAI/WCAG21/Techniques/general/G18).
[WCAG contrast minimum](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html)
uses 4.5:1 for normal text and 3:1 for qualifying large text; thresholds must not
be rounded upward. These functions measure supplied color pairs, not overall
accessibility or legal compliance. Keep keyboard, labels, focus, text sizes and
non-color indicators in the application's verification.
