# Themed overlays and notifications

App-owned tooltips, context menus, popovers, dialogs, modals and notifications
are part of design-system adoption. They must use the active theme's surfaces,
foreground, borders, typography, focus and motion settings. An otherwise themed
page with an unstyled portal or default-library toast is not a completed migration.

## Required adoption policy

- Use a styled app dialog for application prompts and confirmations. Do not use
  JavaScript `alert`, `confirm` or `prompt`. A **styled native `<dialog>`** opened
  with `showModal()` is supported; native element semantics are useful and are
  distinct from blocking browser message boxes. See [dialog](components.md).
- Use an actual themed tooltip for supplemental app hints, associated with its
  trigger and available by keyboard. Do not rely on native `title` tooltips.
  Keep accessible names and always-visible essential information independently.
  A tooltip is not an interactive menu, and interactive content needs a popover.
- When an app offers a context menu, style its surface, items, separators, focus,
  disabled and selected states. Supply keyboard opening, arrow navigation,
  activation, dismissal and focus return through the chosen behavior engine.
  Do not suppress normal browser context menus throughout the page.
- Place overlay/notification roots inside the same theme scope, or propagate the
  resolved theme variables/attributes to the actual portal root. Do not assume
  component-tree context alone transfers CSS inheritance to a body-level portal.
  Recheck on theme changes, embedded roots and more than one app/theme on a page.
- Use notification text that explains success/failure, not color alone. Keep
  essential failures/actions available persistently; a toast is not the only
  record of an important validation error or action result. Avoid duplicate
  announcements, avoid stealing focus and allow users to dismiss messages.

The current presentation primitives are `.syw-tooltip`, `.syw-menu`,
`.syw-menu__item`, `.syw-menu__separator` and `.syw-popover`. They use semantic
surface/foreground tokens instead of browser/library colors. They are experimental
CSS skins, **not** complete positioning, tooltip or menu controllers. Bind them
to an accessible existing engine while preserving its event/ARIA behavior.
Use `.syw-dialog` and its documented structure for native dialog presentation.
Custom translucent themes must provide an opaque readable overlay surface or
explicitly test the composited contrast against every underlying background.

## Optional React Toastify module

The independently packed `@syw/design-toastify` adapter supports React 18/19 and
React Toastify 11 (peer range `^11.1.0`; tested at 11.1.0). It adds no React or
Toastify dependency to core styles, the appearance runtime or form computation.
Install the exact matching tarball, React/React DOM and the reviewed Toastify pin:

```sh
npm install --save-exact react-toastify@11.1.0 https://cdn.sywapps.com/ui/0.1.31/packages/tarballs/syw-design-toastify-0.1.31.tgz
```

```jsx
import { SywToastContainer, createSywToast } from '@syw/design-toastify';
import '@syw/design-toastify/style.css';
// Import the application's SYW core and selected theme separately.

const notifications = createSywToast({containerId: 'settings'});
function NotificationRoot() {
  // Mount inside the active CSS theme scope, alongside its application content.
  return <SywToastContainer containerId="settings" aria-label="Settings notifications" />;
}
notifications.success('Settings saved');
notifications.error('Saving failed. Your edits are still available.');
const id = notifications.loading('Saving settings…');
// After the host's operation completes:
notifications.update(id, {
  render: 'Settings saved', type: 'success', isLoading: false, autoClose: 5000,
});
```

`SywToastContainer` retains Toastify's layout, close controls, pause-on-hover and
focus-loss behavior and keyboard support. Its default is bottom-right, four
visible messages, newest first, no click-to-close or drag dismissal, and a
five-second timeout inherited by routine messages. Standard messages announce as
`status`; errors announce as `alert` and remain until dismissed. Loading messages
remain until explicitly updated/dismissed. Override text, timing, placement and
container props where needed; localize both content and labels. Provide a custom
localized close-button component if required. Preserve readable timing and verify
the flow with assistive technology in the consuming application.

`createSywToast` returns `notify`, `info`, `success`, `warning`, `error`, `loading`,
`update`, `dismiss`, `isActive` and `clearWaitingQueue`. The convenience `sywToast`
uses container ID `syw`, matching the default component. A client fixes its own
container ID, so per-call options cannot accidentally route to another themed app.
Separate apps can mount separate IDs/scopes. Queued notifications need a matching
mounted container. Host effects, actions, persistence, deduplication IDs, ordering
and cleanup on unmount remain caller-owned. The module does not wrap the entire
Toastify API or replace application workflow state.

Custom class names are appended while the SYW container marker is retained. Skin
rules also style Toastify's descendants, so a message-specific class does not
silently restore vendor colors. Import the skin once; it is intentionally not
injected by the module. Toastify 11 itself injects its base CSS. The optional raw
skin is also published at `../integrations/react-toastify.css` for existing
Toastify installations; apply `syw-toast-container` to their container and ensure
timing integration before claiming equivalence to the adapter.

The adapter/skin preserve CSS timer duration even when foundation reduced-motion
rules shorten visual animations. The progress indicator advances at its endpoint
in reduced motion; it does not turn a five-second message into a one-millisecond
message. Keep the adapter's duration variable when overriding inline styles.
Caller-supplied `progress`, transitions and arbitrary render functions need their
own verification. Bundle this optional package and peers through the app's build;
its bare imports do not work as a direct browser URL without an import map.
See upstream [styling](https://fkhadra.github.io/react-toastify/how-to-style/) and
[accessibility](https://fkhadra.github.io/react-toastify/accessibility/) guidance.

## Enforce through tooling and real rendered checks

Consumer agents must inventory these surfaces, migrate them or report an explicit
gap, and include them in acceptance evidence. Enable ESLint's `no-alert: error`
in browser application code. Review native `title` hints and bare vendor overlay
imports in the migration audit; retain legitimate document/frame titles and
third-party application behavior outside the owned surface. An application may
restrict direct vendor imports to its shared overlay adapter to prevent bypasses.

This repository runs `test:overlay-policy` on owned package/example code to reject
browser message-box calls and native app `title` hints, and browser checks for
explicit foreground/background, theme changes, focus states, separate Toastify
containers, dismissal, updates and reading deadlines in reduced motion. This does
not install enforcement into consumer repositories or certify unseen portals.
CSS cannot universally enforce adoption in arbitrary apps. Their sessions own
lint/CI integration, existing-engine bridges and the following required checks:

1. Open each tooltip/menu/dialog/toast in light, dark and high-contrast themes.
2. Verify the actual portal root's computed background/foreground and contrast;
   test against varied underlying content when alpha is used.
3. Exercise keyboard open/navigation/activation/Escape/Tab/focus return where
   applicable, including disabled state and visible focus.
4. Verify live announcements, close labels, readable timeouts, reduced motion,
   zoom/text scaling and more than one themed app/container.
5. Confirm there are no remaining default browser message boxes or unstyled app
   overlays. Record intentional native/third-party exceptions with their scope.
