# Architecture

SYW Design System is framework-neutral. The stable public contract is CSS custom properties, `.syw-*` classes, semantic HTML structure, and optional runtime helpers.

The full product scope also includes independently consumable form/input and
canvas companion modules, composed templates and reusable visual profiles. These
are incomplete; see [coverage and extraction boundaries](scope-and-coverage.md).
Form generation must remain usable without SYW styling. Canvas adapters accept
the host's graph elements and state. Framework-neutral contracts do not imply
that every framework already has a renderer adapter.

## Layers

1. **Brand primitives** — raw SYW colours, radii, spacing and typography values.
2. **Semantic tokens** — canvas, surface, text, primary, secondary, border, status, focus, shadow and gradients.
3. **Base** — resets and document defaults that are safe for websites and apps.
4. **Components** — buttons, cards, fields, chips, navigation, dialogs, media wrappers and similar reusable primitives.
5. **Shells** — explicit context-dependent layout: website, app, workspace, media and bare.
6. **Patterns** — composed UI such as page headers, appearance settings, sidebars and settings panes.
7. **Recipes/effects** — optional expressive behavior such as glow, hover lift and impact shake.
8. **Runtime** — framework-neutral appearance and layout helpers.
9. **Adapters** — React, MUI and future toolkit adapters that consume the same core contract.

## Non-negotiable rule

Foundation and base layers must not encode application-shell assumptions. For example, `body { overflow: hidden }` is forbidden in core. A fixed viewport belongs to `.syw-shell--app` or another explicitly selected shell.

## Appearance contract

Root data attributes are the browser-level state contract:

- `data-theme`
- `data-mode`
- `data-density`
- `data-text-size`
- `data-font`
- `data-motion`

Components consume semantic tokens only. Product-specific tokens stay in product packages and must not leak into generic core unless they prove generally reusable.

## Frameworks

React wrappers render the same `.syw-*` DOM contract as plain HTML/Jinja. MUI is an adapter rather than the owner of the design language. Native GUI frameworks can consume generated token JSON and dedicated adapters.
