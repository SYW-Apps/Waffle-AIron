# Existing MUI applications

Keep the application's current MUI major, providers, routing and theme ownership.
The design-system MUI package currently exports **only `sywMuiCssVars`**. It is
not a drop-in MUI theme, `ThemeProvider`, component kit or cross-version guarantee.
Read the [implementation workflow](implementation.md) and [React guide](react.md).

## Install the matching adapter only when needed

```sh
npm install --save-exact https://cdn.sywapps.com/ui/0.1.31/packages/tarballs/syw-design-mui-0.1.31.tgz
```

```ts
import { sywMuiCssVars } from '@syw/design-mui';
// primary, secondary, backgroundDefault, backgroundPaper,
// textPrimary, textSecondary, divider: semantic CSS variable expressions.
```

Use these values at a CSS-capable boundary of the existing application. For
example, a plain wrapper can share the semantic surfaces without replacing the
MUI provider:

```tsx
import type { ReactNode } from 'react';
import { sywMuiCssVars } from '@syw/design-mui';
export function SharedSurface({ children }: { children: ReactNode }) {
  return <section style={{background:sywMuiCssVars.backgroundPaper,
    color:sywMuiCssVars.textPrimary, border:`1px solid ${sywMuiCssVars.divider}`}}>
    {children}
  </section>;
}
```

MUI palette utilities may parse colors and perform calculations in JavaScript.
Do not assume that an unresolved `var(...)` string works in every palette slot
or MUI version. Check the installed MUI implementation/documentation and test the
specific integration. If a concrete color is required, resolve it at the correct
host/theme boundary and update it when appearance changes; do not freeze a one-time
computed palette while the CSS theme changes underneath it.

Keep MUI's existing reset/provider ordering explicit. Adopt shared CSS/classes for
one ordinary flow, verify that resets, portal menus, dialogs and form focus still
work, and retain MUI controls when there is no verified replacement. Preserve
existing dynamic contrast and custom themes. Report a shared adapter gap upstream
rather than inventing a supposedly universal `createSywMuiTheme` API.
