# Adopting SYW Design System with an agent

Start with the [generic implementation guide](implementation.md), then select
its platform page. This page adds the agent workflow and ownership boundaries.

Read [scope and coverage](scope-and-coverage.md) first. Ordinary CSS field classes
and static chips do not replace JSON form generation, expression pills or a
condition editor. Shared canvas/profile modules are also unfinished. Preserve
existing form schemas, field semantics, editors, templates and canvas behavior
when the documented release has no equivalent implementation.

Use this guide with the manifest and catalogue from the **same exact release**.
The release-local `../llms.txt` is the discovery entry point. `../catalogue.json`
is the machine-readable list of supported classes, tokens, examples, status,
appearance support and accessibility responsibilities. It is not an exhaustive
application framework or a promise that CSS implements interaction behaviour.

## Resolve the release first

For an existing consumer, read its dependency pins and lockfile. Keep its pinned
release unless the task includes an upgrade. For a new consumer, resolve
`https://cdn.sywapps.com/ui/v0/manifest.json`, record its `version`, then fetch
the exact `/ui/<version>/manifest.json`, `catalogue.json`, `llms.txt` and
`packages/tarballs/index.json`. Verify that the exact manifest identifies the
chosen version. Use the tarball index's filenames and the manifest's SHA-256
hashes; install immutable URLs and commit the application's lockfile.
A URL dependency is fetched at install time; application imports are bundled
only by the app's build. For disconnected installs, vendor verified tarballs or
use an approved local mirror. See the distribution guide.

For this built release, the version is **0.1.31**. A React application can
install the matching core and adapter together:

```sh
npm install --save-exact https://cdn.sywapps.com/ui/0.1.31/packages/tarballs/syw-design-system-0.1.31.tgz https://cdn.sywapps.com/ui/0.1.31/packages/tarballs/syw-design-react-0.1.31.tgz
```

These URLs become usable after publication. A source PR or successful build is
not evidence of publication. Registry publication is separate; do not assume
`npm install @syw/design-system` resolves a published registry package.

## Consumer ownership

Assessing or listing a consumer does not authorize changes in that repository.
Consumer sessions own their migrations, CI and deployment. Use these docs and
handoff prompts; only implement a consumer migration here when explicitly assigned.
Do not add or replace CI/deployment infrastructure as an incidental styling change.

## Inspect before editing

1. Read the target repository's instructions, package manifests, entry point,
   theme provider, global CSS, appearance persistence and relevant CI workflows.
2. Identify whether the target owns its document or is embedded in another UI.
   Select the [adoption route](adoption.md) and [distribution policy](distribution.md).
3. Select one real user flow. List its existing controls and match catalogue
   items by `id`, `classes`, `tokens` and `tags`. Use existing patterns before
   introducing a wrapper or proposing a new shared component.
4. Audit existing theme generation, dynamic color/contrast adjustment, custom
   theme data and effects. Read [theme-builder parity](theme-builder-parity.md).
   Preserve existing calculations and richer user data; semantic tokens alone do
   not replace them. Use [color tools](color.md) where they cover the real pair.
5. Record unsupported requirements explicitly. The MUI package currently exports
   semantic-variable mappings; it is not a complete MUI theme/provider or a
   cross-version compatibility guarantee. React wrappers support React 18 and 19.

## Implement the boundary correctly

- For a standalone document, import `@syw/design-system/syw.css` once. Load the
  selected built-in theme file as well when using Waffler or Neutral; the
  aggregate bundle contains the default SYW Apps theme only.
- Use semantic `--syw-*` tokens and the catalogue's exact classes. Keep product
  layouts, routes, network calls, validation timing and domain state in the app.
- Preserve the application's appearance storage and existing user choices.
  The optional runtime applies attributes; it does not provide account sync.
- Keep CSS presentation distinct from behaviour. `exampleHtml` shows structure;
  `exampleJavaScript`, when present, completes the plain-HTML interaction demo.
  `exampleReact`, when present, uses the actual adapter API. Other items can use
  semantic JSX with the same classes; there is no wrapper for every element.
- Keep tab/panel IDs unique per instance, labels programmatically associated,
  focus visible, inactive panels hidden, disabled activation blocked, and errors
  expressed through text and semantics. The React adapter owns selection keyboard
  behaviour; HTML consumers implement it. Native dialogs use `showModal()`.
- Embedded Shadow DOM needs inherited foundation tokens and scoped focus,
  density, text-size and motion handling. ShadyDOM compatibility mode requires
  inline template styles prepared with the host's ShadyCSS API; external links
  inside a shadow root are not sufficient. Do not add host-wide resets.
- In Authentik, preserve native `data-theme`; use the integration bridge and
  namespaced SYW state. Keep authentication and account/session logic upstream.
- Bundle exact assets into Tauri/offline builds. Verify that rendering does not
  require a live CDN connection. Keep backend and authentication contracts intact.

## Verify and report

Run the target app's build, type/lint checks where configured, and relevant tests.
Exercise the migrated flow with keyboard and pointer at desktop/mobile sizes,
light/dark/high contrast, cozy/compact and large text. Check disabled, invalid,
empty and loading states that actually exist in that flow. Confirm focus return,
scrolling, saved appearance and offline startup where applicable.

Report changed surfaces, exact package versions, checks performed and remaining
gaps. Distinguish source, CI, publication, image build, deployment and live smoke
verification. Return a reviewable PR through the target project's normal workflow.

## Reusable session prompt

> Adopt the published SYW Design System in `<repository>` on `<branch>` for
> `<one named user flow>`. Read repository instructions first. Resolve an exact
> release and read its `llms.txt`, agent guide, adoption guide, catalogue and
> manifest. Audit current styling and existing adoption before changing code.
> Preserve dynamic contrast and theme-builder capabilities and richer saved data.
> Pin matching core/adapter tarballs and retain the app's lockfile/toolchain.
> Preserve routing, authentication, application behaviour and appearance choices.
> Use shared tokens/classes and documented adapter APIs; keep product-specific
> composition local. Verify the migrated flow, keyboard behaviour, responsive
> layout, appearance variants and relevant CI. Open a focused PR and report
> evidence and gaps; follow the app's existing deployment process.

## Overlay adoption requirement

Tooltips, context menus, dialogs/modals and toasts are required adoption surfaces,
including portal roots. Use [themed overlays](overlays.md), preserve keyboard/focus
and announcement behavior, and include actual rendered evidence. Use styled app
dialogs for prompts; do not leave browser alert/confirm/prompt calls or unstyled
vendor overlays. An optional React Toastify module is available; core remains
independent of it. Consumer owners control their own lint/CI enforcement.
