# Other DOM frameworks and native platforms

The CSS/semantic-HTML contract is framework-neutral. Vue, Svelte and Angular do
not need a React dependency to use it. No dedicated adapters for those frameworks
are currently published. Read [implementation](implementation.md), [HTML](html.md)
and [components](components.md) for the shared behavior and state requirements.

## Vue, Svelte and Angular

Install the exact core tarball using the project's existing package manager and
lockfile. Import core, components and the selected theme once in the owned client
entry point, before app extensions. Use native elements with the documented
classes and the framework's existing state/binding mechanism. For example, these
are Vue 3, Svelte 5 and Angular template fragments, not complete application
bootstraps. Keep the syntax appropriate to the version already installed:

```vue
<label for="name">Display name</label>
<input id="name" class="syw-input" v-model="name">
<button class="syw-button syw-button--primary" type="button" @click="save">Save</button>
```

```svelte
<label for="name">Display name</label>
<input id="name" class="syw-input" bind:value={name}>
<button class="syw-button syw-button--primary" type="button" onclick={save}>Save</button>
```

```html
<!-- Angular template: name/save belong to the existing component. -->
<label for="name">Display name</label>
<input id="name" class="syw-input" [value]="name" (input)="onNameInput($event)">
<button class="syw-button syw-button--primary" type="button" (click)="save()">Save</button>
```

Framework references: [Vue form bindings](https://vuejs.org/guide/essentials/forms.html),
[Svelte 5 event handlers](https://svelte.dev/docs/svelte/v5-migration-guide), and
[Angular event listeners](https://angular.dev/guide/templates/event-listeners).

Keep the existing reactive forms/validation timing, accessible names and disabled
state. Use the exact catalogue's plain-HTML interaction examples as behavior
references for any custom tabs/segmented controls; framework syntax alone does
not supply keyboard behavior. Do not mount React wrappers inside another
framework merely to obtain a CSS class.

Color helpers import from `@syw/design-system/color` without framework code.
The optional appearance runtime is a browser-document adapter; apply it on the
client lifecycle boundary, retain the application's store, and clean up listeners
or resizable helpers on unmount. Server rendering should emit the initial theme
attributes from its known preference/cookie and avoid a mismatched hydration state.

## Native platforms

A native Rust/.NET/Swift/other widget toolkit does not consume browser CSS classes.
The release supplies `tokens.json`, `themes/builtins.json`, appearance schemas and
palette contracts for a native adapter or build-time export. It does not currently
supply native widgets or bindings for those toolkits.

Map semantic roles and mode/preferences to the toolkit deliberately. Resolve any
CSS brand-variable references before generating literal native color values;
do not pass `var(...)` or gradient CSS text to a native color parser. A build step
with JavaScript can use `color.js` to calculate colors and emit data. A runtime
without an ESM-capable JavaScript engine needs an explicit port/binding with
cross-language reference tests; the served JS module is not automatically a Rust
or C# library. Track that as an adapter gap instead of claiming platform support.
