/** Portable sRGB tools. No DOM, framework, storage or network dependency. */
const clamp = value => Math.min(1, Math.max(0, value));
const numberPattern = /^[+-]?(?:\d+\.?\d*|\.\d+)$/;

function number(value, min, max) {
  if (!numberPattern.test(value)) throw new TypeError(`Invalid color channel: ${value}`);
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < min || parsed > max) throw new RangeError(`Color channel outside ${min}..${max}: ${value}`);
  return parsed;
}
function channel(value, max) {
  return value.endsWith('%') ? number(value.slice(0, -1), 0, 100) * max / 100 : number(value, 0, max);
}
function hue(value) {
  const match = /^([+-]?(?:\d+\.?\d*|\.\d+))(deg|turn|rad|grad)?$/.exec(value);
  if (!match) throw new TypeError('Invalid hue');
  const degrees = Number(match[1]) * ({ deg: 1, turn: 360, rad: 180 / Math.PI, grad: 0.9 }[match[2] || 'deg']);
  return ((degrees % 360) + 360) % 360;
}
function finite(value, min, max, name) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max) throw new RangeError(`${name} must be a finite number from ${min} to ${max}`);
}

/** HSL uses degrees and fractions (s/l in 0..1); RGB channels are in 0..255. */
export function hslToRgb(h, s, l) {
  finite(h, -Number.MAX_VALUE, Number.MAX_VALUE, 'hue');
  finite(s, 0, 1, 'saturation'); finite(l, 0, 1, 'lightness');
  const normalized = ((h % 360) + 360) % 360;
  const a = s * Math.min(l, 1 - l);
  const component = n => {
    const k = (n + normalized / 30) % 12;
    return 255 * (l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)));
  };
  return { r: component(0), g: component(8), b: component(4) };
}
export function rgbToHsl(r, g, b) {
  for (const value of [r, g, b]) finite(value, 0, 255, 'RGB channel');
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b), delta = max - min;
  const l = (max + min) / 2;
  if (delta === 0) return { h: 0, s: 0, l };
  const h = max === r ? ((g - b) / delta + (g < b ? 6 : 0)) : max === g ? (b - r) / delta + 2 : (r - g) / delta + 4;
  return { h: h * 60, s: clamp(delta / (1 - Math.abs(2 * l - 1))), l };
}

/** Strict HEX/RGB/HSL parsing. Unresolved CSS expressions are not colors. */
export function parseColor(value) {
  if (typeof value !== 'string') throw new TypeError('Color must be a string');
  const input = value.trim().toLowerCase();
  if (input === 'transparent') return { r: 0, g: 0, b: 0, a: 0 };
  const hex = /^#?([0-9a-f]{3}|[0-9a-f]{4}|[0-9a-f]{6}|[0-9a-f]{8})$/.exec(input);
  if (hex) {
    const digits = hex[1].length <= 4 ? [...hex[1]].map(c => c + c).join('') : hex[1];
    return { r: parseInt(digits.slice(0, 2), 16), g: parseInt(digits.slice(2, 4), 16), b: parseInt(digits.slice(4, 6), 16), a: digits.length === 8 ? parseInt(digits.slice(6), 16) / 255 : 1 };
  }
  const match = /^(rgb|rgba|hsl|hsla)\(([^()]*)\)$/.exec(input);
  if (!match) throw new TypeError(`Unsupported color: ${value}`);
  const comma = match[2].includes(',');
  if (comma && match[2].includes('/')) throw new TypeError('Do not mix comma and slash color syntax');
  const parts = comma ? match[2].split(',').map(s => s.trim()) : match[2].trim().split(/\s*\/\s*/);
  let channels, alpha;
  if (comma) { channels = parts.slice(0, 3); alpha = parts[3]; }
  else { channels = parts[0].split(/\s+/); alpha = parts[1]; }
  if (channels.length !== 3 || parts.length > (comma ? 4 : 2) || (comma && parts.length < 3)) throw new TypeError('Expected three color channels and optional alpha');
  const a = alpha === undefined ? 1 : channel(alpha, 1);
  if (match[1].startsWith('rgb')) return { r: channel(channels[0], 255), g: channel(channels[1], 255), b: channel(channels[2], 255), a };
  if (!channels[1].endsWith('%') || !channels[2].endsWith('%')) throw new TypeError('HSL saturation and lightness require percentages');
  return { ...hslToRgb(hue(channels[0]), channel(channels[1], 1), channel(channels[2], 1)), a };
}
const hexFromRgb = color => '#' + [color.r, color.g, color.b].map(c => Math.round(c).toString(16).padStart(2, '0')).join('');
const decimal = value => Number(value.toFixed(10));
function serialize(color, quantize = false) {
  if (color.a === 1 && quantize) return hexFromRgb(color);
  const values = [color.r, color.g, color.b].map(v => decimal(quantize ? Math.round(v) : v));
  return `rgb(${values.join(' ')}${color.a === 1 ? '' : ` / ${decimal(color.a)}`})`;
}
export function toHex(color) {
  const parsed = parseColor(color);
  if (parsed.a !== 1) throw new TypeError('toHex requires an opaque color; composite alpha first');
  return hexFromRgb(parsed);
}
function composite(foreground, background) {
  const a = foreground.a + background.a * (1 - foreground.a);
  const mix = key => a === 0 ? 0 : (foreground[key] * foreground.a + background[key] * background.a * (1 - foreground.a)) / a;
  return { r: mix('r'), g: mix('g'), b: mix('b'), a };
}
export function compositeColors(foreground, background) {
  return serialize(composite(parseColor(foreground), parseColor(background)));
}
function opaqueBackground(background, options) {
  let parsed = parseColor(background);
  if (parsed.a !== 1) {
    if (!options?.underlay) throw new TypeError('A translucent background requires an opaque underlay');
    const underlay = parseColor(options.underlay);
    if (underlay.a !== 1) throw new TypeError('Underlay must be opaque');
    parsed = composite(parsed, underlay);
  }
  return parsed;
}
function luminance({ r, g, b }) {
  const linear = value => { const c = value / 255; return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; };
  return 0.2126 * linear(r) + 0.7152 * linear(g) + 0.0722 * linear(b);
}
export function getLuminance(color) {
  const parsed = parseColor(color);
  if (parsed.a !== 1) throw new TypeError('Luminance requires an opaque color; composite alpha first');
  return luminance(parsed);
}
function contrast(foreground, background) {
  const a = luminance(composite(foreground, background)), b = luminance(background);
  return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
}
export function getContrastRatio(foreground, background, options) {
  return contrast(parseColor(foreground), opaqueBackground(background, options));
}

/** Preserve hue/saturation/alpha; search both lightness directions, then verify serialized output. */
export function resolveAccessibleColor(foreground, background, targetRatio = 4.5, options) {
  finite(targetRatio, 1, 21, 'targetRatio');
  const fg = parseColor(foreground), bg = opaqueBackground(background, options);
  const originalRatio = contrast(fg, bg);
  const result = (color, ratio, reason) => ({ color, ratio, targetRatio, meetsTarget: ratio >= targetRatio, adjusted: color !== foreground, reason });
  if (originalRatio >= targetRatio) return result(foreground, originalRatio, 'already-passes');
  const { h, s, l } = rgbToHsl(fg.r, fg.g, fg.b);
  const at = lightness => {
    const color = serialize({ ...hslToRgb(h, s, lightness), a: fg.a }, true);
    return { color, ratio: contrast(parseColor(color), bg), distance: Math.abs(lightness - l) };
  };
  const endpoints = [at(0), at(1)];
  const candidates = [];
  for (const endpoint of [0, 1]) {
    if (endpoints[endpoint].ratio < targetRatio) continue;
    let fail = l, pass = endpoint, candidate = endpoints[endpoint];
    // HSL channels are monotone in lightness. Track a passing, quantized color.
    for (let i = 0; i < 40; i++) {
      const mid = (fail + pass) / 2, next = at(mid);
      if (next.ratio >= targetRatio) { pass = mid; candidate = next; }
      else fail = mid;
    }
    candidates.push(candidate);
  }
  candidates.sort((a, b) => a.distance - b.distance || b.ratio - a.ratio);
  const chosen = candidates[0] || endpoints.sort((a, b) => b.ratio - a.ratio || a.distance - b.distance)[0];
  return result(chosen.color, chosen.ratio, candidates.length ? 'adjusted' : 'unreachable');
}
export function findClosestAccessibleColor(foreground, background, targetRatio = 4.5, options) {
  const result = resolveAccessibleColor(foreground, background, targetRatio, options);
  if (!result.meetsTarget) throw new RangeError(`Contrast ${targetRatio}:1 is unreachable at the supplied opacity/background (best ${result.ratio}:1)`);
  return result.color;
}

export function rotateHue(color, degrees) {
  finite(degrees, -Number.MAX_VALUE, Number.MAX_VALUE, 'degrees');
  const parsed = parseColor(color), { h, s, l } = rgbToHsl(parsed.r, parsed.g, parsed.b);
  return serialize({ ...hslToRgb(h + degrees, s, l), a: parsed.a }, true);
}
export function adjustLightness(color, delta) {
  finite(delta, -1, 1, 'delta');
  const parsed = parseColor(color), { h, s, l } = rgbToHsl(parsed.r, parsed.g, parsed.b);
  return serialize({ ...hslToRgb(h, s, clamp(l + delta)), a: parsed.a }, true);
}
/** Weight belongs to the first color; interpolation uses premultiplied encoded sRGB. */
export function mixColors(first, second, weight = 0.5) {
  finite(weight, 0, 1, 'weight');
  const a = parseColor(first), b = parseColor(second), alpha = a.a * weight + b.a * (1 - weight);
  const mix = key => alpha === 0 ? 0 : (a[key] * a.a * weight + b[key] * b.a * (1 - weight)) / alpha;
  return serialize({ r: mix('r'), g: mix('g'), b: mix('b'), a: alpha }, true);
}
export function withAlpha(color, alpha) {
  finite(alpha, 0, 1, 'alpha');
  return serialize({ ...parseColor(color), a: alpha });
}
export function getColorHarmonies(primary) {
  const base = serialize(parseColor(primary), true), rotate = degrees => rotateHue(base, degrees);
  return { primary: base, complement: rotate(180), triadic: [base, rotate(120), rotate(240)], tetradic: [base, rotate(90), rotate(180), rotate(270)], analogous: [rotate(-30), base, rotate(30)], splitComplementary: [base, rotate(150), rotate(210)] };
}
/** Explicit pairs keep page/panel/button backgrounds distinct; no global compliance claim. */
export function resolveTextColors(pairs, targetRatio = 4.5) {
  finite(targetRatio, 1, 21, 'targetRatio');
  if (!pairs || typeof pairs !== 'object' || Array.isArray(pairs) || !Object.keys(pairs).length) throw new TypeError('pairs must be a non-empty named color-pair object');
  const entries = Object.entries(pairs).map(([key, pair]) => [key, resolveAccessibleColor(pair.foreground, pair.background, targetRatio, pair)]);
  const results = Object.fromEntries(entries);
  return { colors: Object.fromEntries(entries.map(([key, value]) => [key, value.color])), results, meetsTarget: entries.every(([, value]) => value.meetsTarget) };
}
