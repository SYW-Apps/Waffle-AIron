const ROOT = document.documentElement;
const allowed = {
  mode: ['light', 'dark', 'high-contrast'],
  density: ['cozy', 'compact'],
  textSize: ['small', 'default', 'large'],
  font: ['system', 'inter', 'classic', 'serif', 'mono'],
  motion: ['full', 'reduced']
};

const THEME_ID_PATTERN = /^[a-z0-9][a-z0-9._-]*$/;
const COLOR_PATTERN = /^(#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})|rgba?\([0-9 ,.]+\)|hsla?\([0-9 ,.%-]+\))$/;
const CUSTOM_THEME_STYLE_ATTRIBUTE = 'data-syw-custom-theme';
const APPEARANCE_STATE_THEME_ATTRIBUTE = 'data-syw-appearance-state-theme';
const PROFILE_KEYS = ['schemaVersion', 'theme', 'mode', 'density', 'textSize', 'font', 'motion', 'appOverrides'];
const OVERRIDE_KEYS = ['theme', 'mode', 'density', 'textSize', 'font', 'motion'];
const PALETTE_KEYS = [
  'canvas', 'surface', 'surfaceRaised', 'text', 'textMuted',
  'line', 'lineStrong', 'primary', 'secondary', 'accent',
  'onPrimary', 'danger', 'onDanger', 'success', 'warning'
];
const PALETTE_VARIABLES = {
  canvas: '--syw-color-canvas',
  surface: '--syw-color-surface',
  surfaceRaised: '--syw-color-surface-raised',
  text: '--syw-color-text',
  textMuted: '--syw-color-text-muted',
  line: '--syw-color-line',
  lineStrong: '--syw-color-line-strong',
  primary: '--syw-color-primary',
  secondary: '--syw-color-secondary',
  accent: '--syw-color-accent',
  onPrimary: '--syw-color-on-primary',
  danger: '--syw-color-danger',
  onDanger: '--syw-color-on-danger',
  success: '--syw-color-success',
  warning: '--syw-color-warning'
};

function dataAttribute(attr, prefix = '') {
  return `data-${prefix ? `${prefix}-` : ''}${attr}`;
}

function validAppearanceValue(key, value) {
  if (key === 'theme') return typeof value === 'string' && value.length <= 80 && THEME_ID_PATTERN.test(value);
  return !allowed[key] || allowed[key].includes(value);
}

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function hasOnlyKeys(value, allowedKeys) {
  return Object.keys(value).every((key) => allowedKeys.includes(key));
}

function validColor(value) {
  if (typeof value !== 'string' || value.length === 0 || value.length > 32 || !COLOR_PATTERN.test(value)) return false;
  if (typeof CSS !== 'undefined' && typeof CSS.supports === 'function') return CSS.supports('color', value);
  return true;
}

function validatePalette(palette, path, errors) {
  if (!isRecord(palette)) {
    errors.push(`${path} must be an object`);
    return;
  }
  if (!hasOnlyKeys(palette, PALETTE_KEYS)) errors.push(`${path} contains unsupported fields`);
  for (const key of PALETTE_KEYS) {
    if (!(key in palette)) errors.push(`${path}.${key} is required`);
    else if (!validColor(palette[key])) errors.push(`${path}.${key} must be a supported color value`);
  }
}

function validateThemeRef(ref, path, errors) {
  if (!isRecord(ref)) {
    errors.push(`${path} must be an object`);
    return;
  }
  if (!hasOnlyKeys(ref, ['kind', 'id'])) errors.push(`${path} contains unsupported fields`);
  if (!['builtin', 'custom'].includes(ref.kind)) errors.push(`${path}.kind is invalid`);
  if (typeof ref.id !== 'string' || ref.id.length === 0 || ref.id.length > 80 || !THEME_ID_PATTERN.test(ref.id)) {
    errors.push(`${path}.id is invalid`);
  }
}

function validateProfileFields(value, path, errors, partial = false) {
  if (!isRecord(value)) {
    errors.push(`${path} must be an object`);
    return;
  }
  const required = partial ? [] : ['theme', 'mode', 'density', 'textSize', 'font', 'motion'];
  for (const key of required) {
    if (!(key in value)) errors.push(`${path}.${key} is required`);
  }

  if ('theme' in value) validateThemeRef(value.theme, `${path}.theme`, errors);
  if ('mode' in value && !['auto', ...allowed.mode].includes(value.mode)) errors.push(`${path}.mode is invalid`);
  if ('density' in value && !allowed.density.includes(value.density)) errors.push(`${path}.density is invalid`);
  if ('textSize' in value && !allowed.textSize.includes(value.textSize)) errors.push(`${path}.textSize is invalid`);
  if ('font' in value && !allowed.font.includes(value.font)) errors.push(`${path}.font is invalid`);
  if ('motion' in value && !allowed.motion.includes(value.motion)) errors.push(`${path}.motion is invalid`);
}

export function validateCustomTheme(theme) {
  const errors = [];
  if (!isRecord(theme)) return { valid: false, errors: ['theme must be an object'] };
  if (!hasOnlyKeys(theme, ['schemaVersion', 'id', 'name', 'description', 'modes'])) errors.push('theme contains unsupported fields');
  if (theme.schemaVersion !== 1) errors.push('schemaVersion must be 1');
  if (typeof theme.id !== 'string' || theme.id.length === 0 || theme.id.length > 80 || !THEME_ID_PATTERN.test(theme.id)) errors.push('id is invalid');
  if (typeof theme.name !== 'string' || theme.name.length === 0 || theme.name.length > 80) errors.push('name is invalid');
  if (theme.description !== undefined && (typeof theme.description !== 'string' || theme.description.length > 300)) errors.push('description is invalid');

  if (!isRecord(theme.modes)) {
    errors.push('modes must be an object');
  } else {
    if (!hasOnlyKeys(theme.modes, ['light', 'dark', 'highContrast'])) errors.push('modes contains unsupported fields');
    validatePalette(theme.modes.light, 'modes.light', errors);
    validatePalette(theme.modes.dark, 'modes.dark', errors);
    if (theme.modes.highContrast !== undefined) validatePalette(theme.modes.highContrast, 'modes.highContrast', errors);
  }

  return { valid: errors.length === 0, errors };
}

export function validateAppearanceProfile(profile) {
  const errors = [];
  if (!isRecord(profile)) return { valid: false, errors: ['profile must be an object'] };
  if (!hasOnlyKeys(profile, PROFILE_KEYS)) errors.push('profile contains unsupported fields');
  if (profile.schemaVersion !== 1) errors.push('profile.schemaVersion must be 1');
  validateProfileFields(profile, 'profile', errors);

  if (profile.appOverrides !== undefined) {
    if (!isRecord(profile.appOverrides)) {
      errors.push('profile.appOverrides must be an object');
    } else {
      for (const [appId, override] of Object.entries(profile.appOverrides)) {
        if (appId.length > 80 || !THEME_ID_PATTERN.test(appId)) errors.push(`profile.appOverrides has invalid app id: ${appId}`);
        if (!isRecord(override)) {
          errors.push(`profile.appOverrides.${appId} must be an object`);
          continue;
        }
        if (!hasOnlyKeys(override, OVERRIDE_KEYS)) errors.push(`profile.appOverrides.${appId} contains unsupported fields`);
        validateProfileFields(override, `profile.appOverrides.${appId}`, errors, true);
      }
    }
  }

  return { valid: errors.length === 0, errors };
}

export function validateAppearanceState(state) {
  const errors = [];
  if (!isRecord(state)) return { valid: false, errors: ['state must be an object'] };
  if (!hasOnlyKeys(state, ['schemaVersion', 'revision', 'updatedAt', 'profile', 'customThemes'])) errors.push('state contains unsupported fields');
  if (state.schemaVersion !== 1) errors.push('state.schemaVersion must be 1');
  if (typeof state.revision !== 'string' || state.revision.length === 0 || state.revision.length > 160) errors.push('state.revision is invalid');
  if (typeof state.updatedAt !== 'string' || state.updatedAt.length === 0 || Number.isNaN(Date.parse(state.updatedAt))) errors.push('state.updatedAt must be a date-time string');

  const profileValidation = validateAppearanceProfile(state.profile);
  for (const error of profileValidation.errors) errors.push(error);

  const customIds = new Set();
  if (!Array.isArray(state.customThemes)) {
    errors.push('state.customThemes must be an array');
  } else if (state.customThemes.length > 64) {
    errors.push('state.customThemes may contain at most 64 themes');
  } else {
    state.customThemes.forEach((theme, index) => {
      const validation = validateCustomTheme(theme);
      for (const error of validation.errors) errors.push(`state.customThemes[${index}].${error}`);
      if (validation.valid) {
        if (customIds.has(theme.id)) errors.push(`state.customThemes contains duplicate id: ${theme.id}`);
        customIds.add(theme.id);
      }
    });
  }

  const refs = [];
  if (isRecord(state.profile?.theme)) refs.push(['profile.theme', state.profile.theme]);
  if (isRecord(state.profile?.appOverrides)) {
    for (const [appId, override] of Object.entries(state.profile.appOverrides)) {
      if (isRecord(override?.theme)) refs.push([`profile.appOverrides.${appId}.theme`, override.theme]);
    }
  }
  for (const [path, ref] of refs) {
    if (ref.kind === 'custom' && !customIds.has(ref.id)) errors.push(`${path} references missing custom theme: ${ref.id}`);
  }

  return { valid: errors.length === 0, errors };
}

function modeSelectors(themeId, mode) {
  const modeValue = mode === 'highContrast' ? 'high-contrast' : mode;
  const selectors = [
    `html[data-theme="${themeId}"][data-mode="${modeValue}"]`,
    `html[data-syw-theme="${themeId}"][data-syw-mode="${modeValue}"]`
  ];
  if (mode === 'dark') {
    selectors.push(
      `html[data-theme="${themeId}"]:not([data-mode])`,
      `html[data-syw-theme="${themeId}"]:not([data-syw-mode])`
    );
  }
  return selectors.join(',\n');
}

function renderPalette(themeId, mode, palette) {
  const declarations = PALETTE_KEYS.map((key) => `  ${PALETTE_VARIABLES[key]}: ${palette[key]};`);
  declarations.push(`  --syw-gradient-primary: linear-gradient(135deg,${palette.primary},${palette.secondary});`);

  if (mode === 'highContrast') {
    declarations.push('  --syw-shadow-surface: none;');
    declarations.push('  --syw-shadow-elevated: none;');
  } else if (mode === 'light') {
    declarations.push('  --syw-shadow-surface: 0 8px 28px rgba(0,0,0,.08);');
    declarations.push('  --syw-shadow-elevated: 0 14px 42px rgba(0,0,0,.14);');
  } else {
    declarations.push('  --syw-shadow-surface: 0 8px 32px rgba(0,0,0,.34);');
    declarations.push('  --syw-shadow-elevated: 0 16px 50px rgba(0,0,0,.48);');
  }

  declarations.push(`  --syw-header-bg: color-mix(in srgb, ${palette.canvas} 86%, transparent);`);
  declarations.push(`  color-scheme: ${mode === 'light' ? 'light' : 'dark'};`);
  return `${modeSelectors(themeId, mode)} {\n${declarations.join('\n')}\n}`;
}

function renderCustomTheme(theme) {
  const highContrast = theme.modes.highContrast || theme.modes.dark;
  return [
    `/* Generated by SYW Design System runtime for custom theme: ${theme.id} */`,
    renderPalette(theme.id, 'light', theme.modes.light),
    renderPalette(theme.id, 'dark', theme.modes.dark),
    renderPalette(theme.id, 'highContrast', highContrast)
  ].join('\n\n');
}

export function installCustomTheme(theme, options = {}) {
  const validation = validateCustomTheme(theme);
  if (!validation.valid) throw new TypeError(`Invalid SYW Theme v1: ${validation.errors.join('; ')}`);

  const doc = options.document || document;
  const selector = `style[${CUSTOM_THEME_STYLE_ATTRIBUTE}="${theme.id}"]`;
  let style = doc.querySelector?.(selector) || null;
  if (!style) {
    style = doc.createElement('style');
    style.setAttribute(CUSTOM_THEME_STYLE_ATTRIBUTE, theme.id);
    (doc.head || doc.documentElement).appendChild(style);
  }
  style.textContent = renderCustomTheme(theme);

  if (options.activate !== false) {
    setAppearance(
      { theme: theme.id },
      { root: options.root || doc.documentElement, prefix: options.prefix || '' }
    );
  }

  return () => removeCustomTheme(theme.id, { document: doc });
}

export function removeCustomTheme(themeId, options = {}) {
  if (typeof themeId !== 'string' || themeId.length === 0 || themeId.length > 80 || !THEME_ID_PATTERN.test(themeId)) return false;
  const doc = options.document || document;
  const style = doc.querySelector?.(`style[${CUSTOM_THEME_STYLE_ATTRIBUTE}="${themeId}"]`);
  if (!style) return false;
  style.remove();
  return true;
}

export function applyAppearanceState(state, options = {}) {
  const validation = validateAppearanceState(state);
  if (!validation.valid) throw new TypeError(`Invalid SYW Appearance State v1: ${validation.errors.join('; ')}`);

  const doc = options.document || document;
  const root = options.root || doc.documentElement;
  const prefix = options.prefix || '';
  const appId = options.appId;
  if (appId !== undefined && (typeof appId !== 'string' || appId.length === 0 || appId.length > 80 || !THEME_ID_PATTERN.test(appId))) {
    throw new TypeError('Invalid SYW appId');
  }

  const customIds = new Set(state.customThemes.map((theme) => theme.id));
  for (const theme of state.customThemes) {
    installCustomTheme(theme, { document: doc, root, prefix, activate: false });
    const style = doc.querySelector?.(`style[${CUSTOM_THEME_STYLE_ATTRIBUTE}="${theme.id}"]`);
    style?.setAttribute(APPEARANCE_STATE_THEME_ATTRIBUTE, theme.id);
  }

  if (options.pruneStateThemes !== false) {
    const managed = doc.querySelectorAll?.(`style[${APPEARANCE_STATE_THEME_ATTRIBUTE}]`) || [];
    for (const style of managed) {
      const themeId = style.getAttribute(APPEARANCE_STATE_THEME_ATTRIBUTE);
      if (themeId && !customIds.has(themeId)) style.remove();
    }
  }

  const override = appId ? state.profile.appOverrides?.[appId] : undefined;
  const effective = { ...state.profile, ...(override || {}) };
  setAppearance({
    theme: effective.theme.id,
    mode: effective.mode,
    density: effective.density,
    textSize: effective.textSize,
    font: effective.font,
    motion: effective.motion
  }, { root, prefix });

  return {
    revision: state.revision,
    updatedAt: state.updatedAt,
    appId: appId || null,
    customThemeIds: [...customIds],
    appearance: getAppearance({ root, prefix })
  };
}

export function setAppearance(next = {}, options = {}) {
  const root = options.root || ROOT;
  const prefix = options.prefix || '';
  const mapping = { theme:'theme', mode:'mode', density:'density', textSize:'text-size', font:'font', motion:'motion' };
  for (const [key, attr] of Object.entries(mapping)) {
    if (!(key in next)) continue;
    const value = next[key];
    const attribute = dataAttribute(attr, prefix);
    if (value == null || value === 'auto' || value === 'default') root.removeAttribute(attribute);
    else if (validAppearanceValue(key, value)) root.setAttribute(attribute, value);
  }
  root.dispatchEvent(new CustomEvent('syw:appearancechange', { detail: getAppearance(options) }));
}

export function getAppearance(options = {}) {
  const root = options.root || ROOT;
  const prefix = options.prefix || '';
  return {
    theme: root.getAttribute(dataAttribute('theme', prefix)) || 'syw-apps',
    mode: root.getAttribute(dataAttribute('mode', prefix)) || 'dark',
    density: root.getAttribute(dataAttribute('density', prefix)) || 'cozy',
    textSize: root.getAttribute(dataAttribute('text-size', prefix)) || 'default',
    font: root.getAttribute(dataAttribute('font', prefix)) || 'system',
    motion: root.getAttribute(dataAttribute('motion', prefix)) || 'full'
  };
}

export function makeResizableSidebar({ shell, handle, min = 180, max = 520, storageKey = 'syw.sidebar.width' }) {
  const root = typeof shell === 'string' ? document.querySelector(shell) : shell;
  const grip = typeof handle === 'string' ? document.querySelector(handle) : handle;
  if (!root || !grip) return () => {};
  const saved = Number(localStorage.getItem(storageKey));
  if (Number.isFinite(saved) && saved >= min && saved <= max) root.style.setProperty('--syw-sidebar-width', `${saved}px`);
  let active = false;
  const move = (event) => {
    if (!active) return;
    const rect = root.getBoundingClientRect();
    const width = Math.max(min, Math.min(max, event.clientX - rect.left));
    root.style.setProperty('--syw-sidebar-width', `${width}px`);
    localStorage.setItem(storageKey, String(width));
  };
  const up = () => { active = false; document.body.style.userSelect = ''; };
  const down = (event) => { active = true; grip.setPointerCapture?.(event.pointerId); document.body.style.userSelect = 'none'; };
  grip.addEventListener('pointerdown', down); window.addEventListener('pointermove', move); window.addEventListener('pointerup', up);
  return () => { grip.removeEventListener('pointerdown', down); window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
}
