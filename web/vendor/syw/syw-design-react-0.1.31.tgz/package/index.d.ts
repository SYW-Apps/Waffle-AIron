import type React from 'react';

export type SywButtonVariant = 'default' | 'primary' | 'danger' | 'ghost';
export type SywShellKind = 'website' | 'app' | 'workspace' | 'media' | 'bare';

export type SywButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: SywButtonVariant;
};

export type SywSegmentedOption = {
  value: string;
  label: React.ReactNode;
  disabled?: boolean;
};

export type SywSegmentedChangeEvent =
  | React.MouseEvent<HTMLButtonElement>
  | React.KeyboardEvent<HTMLButtonElement>;

export type SywSegmentedProps = Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'> & {
  value: string;
  options: readonly SywSegmentedOption[];
  onChange: (value: string, event: SywSegmentedChangeEvent) => void;
  disabled?: boolean;
};

export type SywTabDefinition = {
  value: string;
  label: React.ReactNode;
  id: string;
  panelId: string;
  disabled?: boolean;
};

export type SywTabChangeEvent =
  | React.MouseEvent<HTMLButtonElement>
  | React.KeyboardEvent<HTMLButtonElement>;

export type SywTabsProps = Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'> & {
  value: string;
  tabs: readonly SywTabDefinition[];
  onChange: (value: string, event: SywTabChangeEvent) => void;
  disabled?: boolean;
};

export type SywSettingProps = React.HTMLAttributes<HTMLDivElement> & {
  label: React.ReactNode;
  description?: React.ReactNode;
  control?: React.ReactNode;
  labelAs?: React.ElementType;
};

export type SywEmptyStateProps = Omit<React.HTMLAttributes<HTMLDivElement>, 'title'> & {
  icon?: React.ReactNode;
  title: React.ReactNode;
  description?: React.ReactNode;
  actions?: React.ReactNode;
  titleAs?: React.ElementType;
};

export function SywButton(props: SywButtonProps): React.ReactElement;
export function SywCard(props: React.HTMLAttributes<HTMLDivElement>): React.ReactElement;
export function SywShell(
  props: React.HTMLAttributes<HTMLDivElement> & { kind?: SywShellKind },
): React.ReactElement;
export function SywSegmented(props: SywSegmentedProps): React.ReactElement;
export function SywTabs(props: SywTabsProps): React.ReactElement;
export function SywSetting(props: SywSettingProps): React.ReactElement;
export function SywEmptyState(props: SywEmptyStateProps): React.ReactElement;
