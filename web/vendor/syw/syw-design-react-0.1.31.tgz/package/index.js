import React from 'react';

function joinClasses(...values) {
  return values.filter(Boolean).join(' ');
}

function firstEnabledIndex(items) {
  return items.findIndex((item) => !item.disabled);
}

function lastEnabledIndex(items) {
  for (let index = items.length - 1; index >= 0; index -= 1) {
    if (!items[index].disabled) return index;
  }
  return -1;
}

function nextEnabledIndex(items, currentIndex, direction) {
  if (items.length === 0) return -1;
  for (let offset = 1; offset <= items.length; offset += 1) {
    const index = (currentIndex + direction * offset + items.length) % items.length;
    if (!items[index].disabled) return index;
  }
  return -1;
}

function navigationTarget(items, currentIndex, key, axis = 'both') {
  if (key === 'Home') return firstEnabledIndex(items);
  if (key === 'End') return lastEnabledIndex(items);
  if ((key === 'ArrowLeft' && axis !== 'vertical') || (key === 'ArrowUp' && axis !== 'horizontal')) return nextEnabledIndex(items, currentIndex, -1);
  if ((key === 'ArrowRight' && axis !== 'vertical') || (key === 'ArrowDown' && axis !== 'horizontal')) return nextEnabledIndex(items, currentIndex, 1);
  return -1;
}

export function SywButton({ variant = 'default', className = '', ...props }) {
  const variantClass = variant === 'default' ? '' : `syw-button--${variant}`;
  return React.createElement('button', {
    ...props,
    className: joinClasses('syw-button', variantClass, className),
  });
}

export function SywCard({ className = '', ...props }) {
  return React.createElement('div', {
    ...props,
    className: joinClasses('syw-card', className),
  });
}

export function SywShell({ kind = 'bare', className = '', ...props }) {
  return React.createElement('div', {
    ...props,
    className: joinClasses('syw-shell', `syw-shell--${kind}`, className),
  });
}

export function SywSegmented({
  value,
  options,
  onChange,
  disabled = false,
  className = '',
  ...props
}) {
  const itemRefs = React.useRef([]);
  const selectedIndex = options.findIndex((option) => option.value === value && !option.disabled);
  const focusableIndex = selectedIndex >= 0 ? selectedIndex : firstEnabledIndex(options);

  const activate = (index, event) => {
    const option = options[index];
    if (!option || disabled || option.disabled) return;
    onChange(option.value, event);
    itemRefs.current[index]?.focus();
  };

  const handleKeyDown = (event, index) => {
    if (disabled || event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey) return;
    const targetIndex = navigationTarget(options, index, event.key);
    if (targetIndex < 0) return;
    event.preventDefault();
    activate(targetIndex, event);
  };

  return React.createElement('div', {
    ...props,
    role: 'radiogroup',
    className: joinClasses('syw-segmented', className),
  }, options.map((option, index) => React.createElement('button', {
    type: 'button',
    role: 'radio',
    'aria-checked': option.value === value,
    disabled: disabled || option.disabled,
    tabIndex: index === focusableIndex ? 0 : -1,
    className: 'syw-segmented__item',
    key: option.value,
    ref: (node) => { itemRefs.current[index] = node; },
    onClick: (event) => activate(index, event),
    onKeyDown: (event) => handleKeyDown(event, index),
  }, option.label)));
}

export function SywTabs({
  value,
  tabs,
  onChange,
  disabled = false,
  className = '',
  ...props
}) {
  const tabRefs = React.useRef([]);
  const selectedIndex = tabs.findIndex((tab) => tab.value === value && !tab.disabled);
  const focusableIndex = selectedIndex >= 0 ? selectedIndex : firstEnabledIndex(tabs);

  const activate = (index, event) => {
    const tab = tabs[index];
    if (!tab || disabled || tab.disabled) return;
    onChange(tab.value, event);
    tabRefs.current[index]?.focus();
  };

  const handleKeyDown = (event, index) => {
    if (disabled || event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey) return;
    const axis = props['aria-orientation'] === 'vertical' ? 'vertical' : 'horizontal';
    const targetIndex = navigationTarget(tabs, index, event.key, axis);
    if (targetIndex < 0) return;
    event.preventDefault();
    activate(targetIndex, event);
  };

  return React.createElement('div', {
    ...props,
    role: 'tablist',
    className: joinClasses('syw-tabs', className),
  }, tabs.map((tab, index) => React.createElement('button', {
    type: 'button',
    role: 'tab',
    id: tab.id,
    'aria-controls': tab.panelId,
    'aria-selected': tab.value === value,
    disabled: disabled || tab.disabled,
    tabIndex: index === focusableIndex ? 0 : -1,
    className: 'syw-tab',
    key: tab.value,
    ref: (node) => { tabRefs.current[index] = node; },
    onClick: (event) => activate(index, event),
    onKeyDown: (event) => handleKeyDown(event, index),
  }, tab.label)));
}

export function SywSetting({
  label,
  description,
  control,
  labelAs = 'p',
  className = '',
  ...props
}) {
  const content = [
    React.createElement(labelAs, { className: 'syw-setting__label', key: 'label' }, label),
  ];
  if (description != null) {
    content.push(
      React.createElement('p', { className: 'syw-setting__description', key: 'description' }, description),
    );
  }

  const children = [
    React.createElement('div', { className: 'syw-setting__content', key: 'content' }, content),
  ];
  if (control != null) {
    children.push(
      React.createElement('div', { className: 'syw-setting__control', key: 'control' }, control),
    );
  }

  return React.createElement('div', {
    ...props,
    className: joinClasses('syw-setting', className),
  }, children);
}

export function SywEmptyState({
  icon,
  title,
  description,
  actions,
  titleAs = 'h3',
  className = '',
  ...props
}) {
  const children = [];
  if (icon != null) {
    children.push(
      React.createElement('div', {
        className: 'syw-empty__icon',
        'aria-hidden': true,
        key: 'icon',
      }, icon),
    );
  }
  children.push(
    React.createElement(titleAs, { className: 'syw-empty__title', key: 'title' }, title),
  );
  if (description != null) {
    children.push(
      React.createElement('p', { className: 'syw-empty__description', key: 'description' }, description),
    );
  }
  if (actions != null) {
    children.push(
      React.createElement('div', { className: 'syw-empty__actions', key: 'actions' }, actions),
    );
  }

  return React.createElement('div', {
    ...props,
    className: joinClasses('syw-empty', className),
  }, children);
}
