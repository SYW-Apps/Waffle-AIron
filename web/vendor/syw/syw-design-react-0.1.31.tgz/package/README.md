# @syw/design-react

Thin React wrappers around the framework-neutral `.syw-*` DOM/CSS contract. React is a peer dependency and is not the owner of styling.

```tsx
import '@syw/design-system/components.css';
import {
  SywButton,
  SywCard,
  SywEmptyState,
  SywSegmented,
  SywSetting,
  SywShell,
  SywTabs,
} from '@syw/design-react';
```

Wrappers are intentionally small. Add one only when it improves ergonomics, accessibility or behavior; do not duplicate every HTML element.

## Controlled selection primitives

`SywSegmented` and `SywTabs` keep the selected value in the consuming application. The adapter owns the repetitive interaction contract: stable Design System classes, roles, programmatic selection state, roving tab stops, Home/End handling and arrow-key navigation.

```tsx
<SywSegmented
  aria-label="View"
  value={view}
  options={[
    { value: 'grid', label: 'Grid' },
    { value: 'list', label: 'List' },
  ]}
  onChange={setView}
/>

<SywTabs
  aria-label="Settings sections"
  value={tab}
  tabs={[
    { value: 'general', label: 'General', id: 'general-tab', panelId: 'general-panel' },
    { value: 'advanced', label: 'Advanced', id: 'advanced-tab', panelId: 'advanced-panel' },
  ]}
  onChange={setTab}
/>

<section id="general-panel" role="tabpanel" aria-labelledby="general-tab" tabIndex={0} hidden={tab !== 'general'}>
  ...
</section>
<section id="advanced-panel" role="tabpanel" aria-labelledby="advanced-tab" tabIndex={0} hidden={tab !== 'advanced'}>
  ...
</section>
```

Segmented choices use radio-group semantics because this wrapper represents a single one-of-many value. For independent toggle buttons, use the framework-neutral `syw-segmented` / `syw-segmented__item` classes directly with `aria-pressed` instead.

Tabs use automatic activation: clicking, Home/End or an arrow key changes the controlled value and moves focus. Each tab definition therefore requires both its own `id` and the `panelId` it controls; the consuming tab panel should point back with `aria-labelledby`.

Tab navigation follows `aria-orientation`: the default horizontal tablist uses Left/Right, while a tablist marked `aria-orientation="vertical"` uses Up/Down. Arrows on the other axis keep their browser behavior, including page scrolling. The consumer supplies any custom vertical layout. Standalone segmented radio groups use all four arrows. Both wrappers leave Alt/Ctrl/Meta shortcuts and events already cancelled by a parent handler untouched.

Keep inactive panels hidden or unmounted. A panel whose first meaningful content is not focusable should have `tabIndex={0}` so Tab can move out of the tablist into its content. These defaults follow the [WAI-ARIA tabs pattern](https://www.w3.org/WAI/ARIA/apg/patterns/tabs/); radio groups inside toolbars need the toolbar's own keyboard model rather than the standalone wrapper's selection behavior.

## Composed application primitives

`SywSetting` renders the shared setting-row structure from a label, optional description and control. `SywEmptyState` renders the shared empty-state structure with optional decorative icon, description and actions. The consumer may select an appropriate heading element with `labelAs` / `titleAs`.

```tsx
<SywSetting
  label="Compact mode"
  description="Reduce control spacing."
  control={<SywButton>Change</SywButton>}
/>

<SywEmptyState
  title="No publishers yet"
  description="Create one to give a CI pipeline scoped write access."
  actions={<SywButton variant="primary">Create publisher</SywButton>}
/>
```

Each immutable design-system release emits this adapter as an independently packable package under `packages/react/`. Registry publication is a separate step.
